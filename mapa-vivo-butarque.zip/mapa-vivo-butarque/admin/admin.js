/*
 * Panel editorial del Mapa vivo de Butarque.
 * Todo pasa por la API /api/admin/... con la cabecera  Authorization: Bearer <clave>.
 * La clave se guarda solo en esta pestaña del navegador (sessionStorage).
 */
"use strict";

const $ = (s) => document.querySelector(s);
const esc = (t) => String(t ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const METODOS = {
  editorial: ["Revisada", "bien"], parentesis: ["Del texto: (año)", "info"], final_del_texto: ["Del texto: al final", "info"],
  hace_n_anios: ["Del texto: «hace N años»", "info"], antes_de_cristo: ["Del texto: a. C.", "info"],
  primer_anio: ["Primer año del texto · revisar", "aviso"],
};
let clave = sessionStorage.getItem("clave") || "";
let capas = [], puntos = [], seleccionado = null;

async function api(ruta, opciones = {}) {
  const r = await fetch("/api" + ruta, {
    ...opciones,
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${clave}`, ...(opciones.headers || {}) },
  });
  if (r.status === 401) { salir(); throw new Error("Clave incorrecta o caducada"); }
  const datos = r.status === 204 ? null : await r.json().catch(() => null);
  if (!r.ok) {
    const d = datos?.detail;
    throw new Error(Array.isArray(d) ? d.map((x) => x.msg).join(" · ") : d || `Error ${r.status}`);
  }
  return datos;
}

function aviso(texto) {
  const el = $("#aviso");
  el.textContent = texto;
  el.hidden = false;
  clearTimeout(aviso.t);
  aviso.t = setTimeout(() => (el.hidden = true), 3500);
}

/* ------------------------------------------------------------------ entrada y navegación */
$("#form-entrar").onsubmit = async (ev) => {
  ev.preventDefault();
  clave = $("#clave").value.trim();
  try {
    await api("/admin/comprobar");
    sessionStorage.setItem("clave", clave);
    arrancar();
  } catch (e) { $("#error-entrar").textContent = e.message; }
};

function salir() {
  clave = "";
  sessionStorage.removeItem("clave");
  document.querySelectorAll("main > section").forEach((s) => (s.hidden = true));
  $("#vista-entrar").hidden = false;
  $("#pestanas").hidden = true;
}
$("#btn-salir").onclick = salir;

const VISTAS = { resumen: verResumen, puntos: verPuntos, aportaciones: verAportaciones, importar: verImportar, qr: verQR };
document.querySelectorAll("[data-vista]").forEach((b) => (b.onclick = () => irA(b.dataset.vista)));

function irA(vista) {
  document.querySelectorAll("[data-vista]").forEach((b) => b.dataset.vista === vista ? b.setAttribute("aria-current", "page") : b.removeAttribute("aria-current"));
  document.querySelectorAll("main > section").forEach((s) => (s.hidden = s.id !== `vista-${vista}`));
  location.hash = vista;
  VISTAS[vista]();
}

async function arrancar() {
  $("#vista-entrar").hidden = true;
  $("#pestanas").hidden = false;
  capas = await fetch("/api/capas").then((r) => r.json());
  irA(location.hash.slice(1) in VISTAS ? location.hash.slice(1) : "resumen");
}

async function actualizarContador() {
  const r = await api("/admin/resumen");
  $("#contador-pendientes").textContent = r.aportaciones_pendientes || "";
  return r;
}

/* ------------------------------------------------------------------ resumen */
async function verResumen() {
  const r = await actualizarContador();
  const cifra = (n, texto, tipo = "") => `<div class="cifra ${n && tipo ? "cifra--" + tipo : ""}"><b>${n}</b>${texto}</div>`;
  $("#vista-resumen").innerHTML = `
    <div class="cifras">
      ${cifra(r.publicados, `puntos publicados (de ${r.puntos})`)}
      ${cifra(r.aportaciones_pendientes, "aportaciones por moderar", "grave")}
      ${cifra(r.fecha_por_revisar, "fechas deducidas que conviene revisar", "alerta")}
      ${cifra(r.sin_fecha, "puntos sin fecha (fuera de la línea del tiempo)", "alerta")}
      ${cifra(r.sin_descripcion, "puntos sin descripción", "alerta")}
      ${cifra(r.fuera_del_kml, "puntos que ya no están en My Maps", "grave")}
      ${cifra(r.editados, "puntos corregidos en este panel")}
      ${cifra(r.recursos, "recursos multimedia")}
    </div>
    <div class="tarjeta">
      <h2>Cómo se trabaja</h2>
      <p>Los puntos llegan del mapa <b>«Geolocalización Línea del tiempo»</b> de Google My Maps. Lo que se corrige aquí
      (texto, fecha, posición) <b>queda protegido</b>: una nueva importación del mapa no lo pisa y avisa del conflicto.</p>
      <p>Última importación: ${r.ultima_importacion ? `${esc(r.ultima_importacion.fecha)} · ${esc(r.ultima_importacion.origen)}` : "ninguna"}</p>
    </div>`;
}

/* ------------------------------------------------------------------ puntos */
async function verPuntos() {
  puntos = await api("/admin/puntos");
  const nombreCapa = Object.fromEntries(capas.map((c) => [c.id, c.nombre_corto || c.nombre]));
  $("#tabla-puntos").innerHTML = `
    <table>
      <thead><tr><th>Punto</th><th>Fecha</th><th>Estado</th><th>Rec.</th></tr></thead>
      <tbody>${puntos.map((p) => {
        const [metodo, tipo] = METODOS[p.fecha_metodo] || ["Sin fecha", "mal"];
        return `<tr data-id="${esc(p.id)}" aria-selected="${p.id === seleccionado}">
          <td><span class="punto-color" style="background:${esc(p.color)}"></span><b>${esc(p.titulo_corto || p.titulo)}</b><br>
              <small>${esc(nombreCapa[p.capa_id] || p.capa_id)} · <code>${esc(p.id)}</code></small></td>
          <td>${esc(p.fecha_texto || "—")}<br><span class="marca marca--${tipo}">${metodo}</span></td>
          <td>${p.publicado ? '<span class="marca marca--bien">Publicado</span>' : '<span class="marca marca--mal">Oculto</span>'}
              ${p.editado_localmente ? '<span class="marca marca--info">Editado aquí</span>' : ""}
              ${p.origen === "kml" && !p.en_kml ? '<span class="marca marca--mal">Ya no está en My Maps</span>' : ""}
              ${!p.largo ? '<span class="marca marca--aviso">Sin descripción</span>' : ""}
              ${p.pendientes ? `<span class="marca marca--aviso">${p.pendientes} por moderar</span>` : ""}</td>
          <td>${p.recursos}</td></tr>`;
      }).join("")}</tbody>
    </table>`;
  document.querySelectorAll("#tabla-puntos tbody tr").forEach((tr) => (tr.onclick = () => editar(tr.dataset.id)));
  if (seleccionado) editar(seleccionado);
}

async function editar(id) {
  seleccionado = id;
  document.querySelectorAll("#tabla-puntos tbody tr").forEach((tr) => tr.setAttribute("aria-selected", tr.dataset.id === id));
  const p = await api(`/admin/puntos/${id}`);
  $("#editor").innerHTML = `
    <div class="tarjeta">
      <h2>${esc(p.titulo)}</h2>
      <small><a href="/p/${esc(p.id)}" target="_blank" rel="noopener">Ver en la app ↗</a> · origen: ${p.origen === "kml" ? "My Maps" : "propio"}</small>
      ${p.editado_localmente ? `<p class="cajita">Este punto se ha corregido en el panel: la próxima importación de My Maps no lo cambiará.</p>` : ""}
      <form id="form-punto">
        <label for="e-titulo">Título</label><input id="e-titulo" type="text" value="${esc(p.titulo)}" required minlength="3">
        <label for="e-corto">Título corto (mapa, rutas, juegos)</label><input id="e-corto" type="text" maxlength="60" value="${esc(p.titulo_corto || "")}">
        <div class="fila">
          <div><label for="e-capa">Capa</label><select id="e-capa">${capas.map((c) => `<option value="${esc(c.id)}" ${c.id === p.capa_id ? "selected" : ""}>${esc(c.nombre)}</option>`).join("")}</select></div>
          <div><label for="e-publicado">Estado</label><select id="e-publicado"><option value="1" ${p.publicado ? "selected" : ""}>Publicado</option><option value="0" ${!p.publicado ? "selected" : ""}>Oculto</option></select></div>
        </div>
        <div class="fila">
          <div><label for="e-anio">Año para ordenar</label><input id="e-anio" type="number" value="${p.anio ?? ""}" placeholder="vacío = sin fecha"></div>
          <div><label for="e-fecha">Fecha que se muestra</label><input id="e-fecha" type="text" maxlength="40" value="${esc(p.fecha_texto || "")}"></div>
        </div>
        <p class="ayuda">Fecha actual: ${(METODOS[p.fecha_metodo] || ["sin fecha"])[0]}. Los años antes de Cristo van en negativo (-1000).</p>
        <div class="fila">
          <div><label for="e-lat">Latitud</label><input id="e-lat" type="number" step="0.000001" value="${p.lat}"></div>
          <div><label for="e-lon">Longitud</label><input id="e-lon" type="number" step="0.000001" value="${p.lon}"></div>
        </div>
        <label for="e-desc">Descripción</label><textarea id="e-desc">${esc(p.descripcion)}</textarea>
        <label for="e-nota">Nota editorial (no se publica)</label><textarea id="e-nota" style="min-height:60px">${esc(p.nota_editorial || "")}</textarea>
        <button class="boton">Guardar cambios</button>
      </form>

      <h3>Recursos</h3>
      ${p.recursos.map((r) => `
        <div class="recurso">
          <span class="marca">${esc(r.tipo)}</span>
          <div><b>${esc(r.titulo || "(sin título)")}</b><br><small>${esc(r.url)}</small><br>
            <small>Autoría: ${esc(r.autoria)} · Licencia: ${esc(r.licencia)} · origen: ${esc(r.origen)}</small></div>
          ${r.origen === "propio" ? `<button class="boton boton--claro" data-borrar="${r.id}" aria-label="Quitar ${esc(r.titulo)}">Quitar</button>` : ""}
        </div>`).join("") || "<p class='ayuda'>Sin recursos.</p>"}
      <details class="cajita"><summary><b>Añadir un recurso</b></summary>
        <form id="form-recurso">
          <div class="fila">
            <div><label for="r-tipo">Tipo</label><select id="r-tipo">${["imagen", "audio", "video", "enlace", "documento", "juego"].map((t) => `<option>${t}</option>`).join("")}</select></div>
            <div><label for="r-licencia">Licencia</label><input id="r-licencia" type="text" value="Pendiente de confirmar"></div>
          </div>
          <label for="r-titulo">Título</label><input id="r-titulo" type="text" required minlength="2">
          <label for="r-url">Dirección (https://… o /media/…)</label><input id="r-url" type="text" required pattern="(https?://|/media/).*">
          <label for="r-autoria">Autoría</label><input id="r-autoria" type="text" required minlength="2">
          <label for="r-alt">Texto alternativo (imágenes)</label><input id="r-alt" type="text" maxlength="200">
          <button class="boton">Añadir</button>
        </form>
      </details>
    </div>`;

  $("#form-punto").onsubmit = async (ev) => {
    ev.preventDefault();
    const num = (v) => (v === "" ? null : Number(v));
    try {
      await api(`/admin/puntos/${id}`, { method: "PUT", body: JSON.stringify({
        titulo: $("#e-titulo").value, titulo_corto: $("#e-corto").value || null, capa_id: $("#e-capa").value,
        publicado: $("#e-publicado").value === "1", anio: num($("#e-anio").value), fecha_texto: $("#e-fecha").value || null,
        lat: num($("#e-lat").value), lon: num($("#e-lon").value), descripcion: $("#e-desc").value, nota_editorial: $("#e-nota").value || null,
      }) });
      aviso("Guardado");
      verPuntos();
    } catch (e) { aviso(e.message); }
  };
  $("#form-recurso").onsubmit = async (ev) => {
    ev.preventDefault();
    try {
      await api(`/admin/puntos/${id}/recursos`, { method: "POST", body: JSON.stringify({
        tipo: $("#r-tipo").value, titulo: $("#r-titulo").value, url: $("#r-url").value, autoria: $("#r-autoria").value,
        licencia: $("#r-licencia").value, texto_alt: $("#r-alt").value }) });
      aviso("Recurso añadido");
      editar(id);
    } catch (e) { aviso(e.message); }
  };
  document.querySelectorAll("[data-borrar]").forEach((b) => (b.onclick = async () => {
    try { await api(`/admin/recursos/${b.dataset.borrar}`, { method: "DELETE" }); aviso("Recurso quitado"); editar(id); }
    catch (e) { aviso(e.message); }
  }));
}

/* ------------------------------------------------------------------ aportaciones */
async function verAportaciones(estadoFiltro = "pendiente") {
  const lista = await api(`/admin/aportaciones?estado=${estadoFiltro}`);
  actualizarContador();
  $("#vista-aportaciones").innerHTML = `
    <p>Mostrar:
      ${["pendiente", "aprobada", "rechazada"].map((e) => `<button class="boton ${e === estadoFiltro ? "" : "boton--claro"}" data-filtro="${e}">${e}s</button>`).join(" ")}</p>
    ${lista.length ? lista.map((a) => `
      <div class="tarjeta aportacion">
        <small>${esc(a.creada)} · <a href="/p/${esc(a.punto_id)}" target="_blank" rel="noopener">${esc(a.punto)}</a></small>
        <blockquote>${esc(a.texto)}</blockquote>
        <small>Firma: ${esc(a.nombre || "Anónimo")}</small>
        ${a.estado === "pendiente" ? `<div class="acciones">
          <button class="boton boton--ok" data-accion="aprobar" data-id="${a.id}">Aprobar y publicar</button>
          <button class="boton boton--peligro" data-accion="rechazar" data-id="${a.id}">Rechazar</button></div>` : ""}
      </div>`).join("") : `<p class="ayuda">No hay aportaciones ${estadoFiltro}s.</p>`}`;
  document.querySelectorAll("[data-filtro]").forEach((b) => (b.onclick = () => verAportaciones(b.dataset.filtro)));
  document.querySelectorAll("[data-accion]").forEach((b) => (b.onclick = async () => {
    await api(`/admin/aportaciones/${b.dataset.id}/${b.dataset.accion}`, { method: "POST" });
    aviso(b.dataset.accion === "aprobar" ? "Publicada en la ficha del punto" : "Rechazada");
    verAportaciones(estadoFiltro);
  }));
}

/* ------------------------------------------------------------------ importar */
function verImportar() {
  $("#vista-importar").innerHTML = `
    <div class="tarjeta">
      <h2>Volver a importar el mapa de My Maps</h2>
      <p>Se reconocen los puntos aunque se les cambie el título en My Maps (si siguen en el mismo sitio). Lo corregido en este panel no se pisa.</p>
      <form id="form-importar">
        <label for="kml-url">Dirección del KML (vacío = el fichero configurado en el servidor)</label>
        <input id="kml-url" type="url" placeholder="https://www.google.com/maps/d/kml?mid=...&forcekml=1">
        <button class="boton">Importar</button>
      </form>
      <div id="informe" class="informe"></div>
    </div>`;
  $("#form-importar").onsubmit = async (ev) => {
    ev.preventDefault();
    $("#informe").innerHTML = "<p>Importando…</p>";
    try {
      const url = $("#kml-url").value.trim();
      const inf = await api("/admin/importar", { method: "POST", body: JSON.stringify(url ? { kml_url: url } : {}) });
      const lista = (t, xs, f = (x) => esc(typeof x === "string" ? x : JSON.stringify(x))) =>
        `<h3>${t} (${xs.length})</h3>${xs.length ? `<ul>${xs.map((x) => `<li>${f(x)}</li>`).join("")}</ul>` : ""}`;
      $("#informe").innerHTML = `
        <h3>Mapa: ${esc(inf.mapa)}</h3>
        ${lista("Nuevos", inf.nuevos)}
        ${lista("Actualizados", inf.actualizados, (x) => `${esc(x.id)}: ${esc(x.campos.join(", "))}`)}
        ${lista("Renombrados en My Maps", inf.renombrados, (x) => `${esc(x.id)}: «${esc(x.antes)}» → «${esc(x.ahora)}»`)}
        ${lista("Conflictos (se conserva lo editado aquí)", inf.conflictos, (x) => `${esc(x.id)}: ${esc(x.campos.join(", "))}`)}
        ${lista("Ya no están en My Maps (no se borran)", inf.desaparecidos)}
        <h3>Sin cambios: ${inf.sin_cambios.length}</h3>
        <p>Imágenes: ${inf.imagenes.nuevas} nuevas, ${inf.imagenes.url_cambiada} con dirección cambiada.</p>
        ${lista("Avisos", inf.avisos)}`;
      actualizarContador();
    } catch (e) { $("#informe").innerHTML = `<p class="error">${esc(e.message)}</p>`; }
  };
}

/* ------------------------------------------------------------------ códigos QR */
async function verQR() {
  const ps = await fetch("/api/puntos").then((r) => r.json());
  $("#vista-qr").innerHTML = `
    <p class="no-imprimir">Una hoja con el código QR de cada punto publicado, para las placas en la calle.
      <button class="boton" onclick="print()">Imprimir</button></p>
    <div class="qr-rejilla">${ps.map((p) => `
      <div class="qr"><img src="/api/puntos/${esc(p.id)}/qr.png" alt="Código QR de ${esc(p.titulo)}" loading="lazy">
        <strong>${esc(p.titulo_corto || p.titulo)}</strong><small>${esc(p.fecha_texto || "")}</small></div>`).join("")}
    </div>`;
}

if (clave) api("/admin/comprobar").then(arrancar).catch(salir);
