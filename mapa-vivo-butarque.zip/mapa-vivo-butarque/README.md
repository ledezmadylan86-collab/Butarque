# Mapa vivo de Butarque · prototipo de validación

Prototipo funcional de la **línea 2 (2.º DAM)** del proyecto intermodular Butarque. Toma el mapa de Google My Maps de la Mesa Comunitaria (**«Geolocalización Línea del tiempo»**, 21 puntos en 5 capas) y lo convierte en un mapa interactivo y enriquecido, alimentado por un servidor de contenidos propio.

No es la entrega del alumnado. Sirve para **validar ideas y decisiones técnicas antes de plantear el reto**: qué datos trae realmente el mapa, qué falta, qué problemas aparecen al sincronizar con My Maps y qué tiene que resolver cada ciclo.

```
 Google My Maps (Mesa) ──KML──▶  SERVIDOR DE CONTENIDOS (FastAPI + SQLite)  ──API REST──▶  App móvil web (PWA)
                                   · importador con reglas de sincronización               · mapa, capas, línea del tiempo
 enriquecimiento.json ───────────▶ · recursos multimedia, rutas, recuerdos                 · fichas con fotos, audio, juegos
 (fechas, títulos cortos,          · moderación de aportaciones                            · rutas, cerca de mí, geovallas
  rutas, enlaces al Arcade)        · QR, GeoJSON, exportación para el Arcade               · sin conexión, lista accesible
                                            ▲
                                            └── Panel editorial (/admin) para la Mesa Comunitaria
```

## Ponerlo en marcha

**Con contenedores** (recomendado, igual que el Arcade):

```bash
docker compose up --build -d
```

| Dirección | Qué es |
|---|---|
| http://localhost:8090 | La app. En el ordenador, abre las herramientas de desarrollo (F12) y activa la vista de móvil |
| http://localhost:8090/?simular=1 | Igual, pero pulsando «Cerca de mí» y tocando el mapa se simula la posición (para probar geovallas sin salir a la calle) |
| http://localhost:8090/p/la-copa-de-villaverde | Enlace directo a un punto (lo que abren los QR) |
| http://localhost:8090/admin/ | Panel editorial. Clave: `ADMIN_TOKEN` de `compose.yaml` |
| http://localhost:8090/docs | Documentación interactiva de la API (OpenAPI) |

**Sin contenedores:**

```bash
cd servidor
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
ADMIN_TOKEN=demo-butarque uvicorn app.main:app --reload       # http://localhost:8000
python -m pytest -q                                            # 36 pruebas
```

La primera vez que arranca con la base de datos vacía, importa el KML de `servidor/datos/`.

## Qué incluye

**Servidor de contenidos** (`servidor/app/`)
- `kml.py`: lee el KML de My Maps (capas, puntos, fotos) y deduce la fecha de cada hito del texto.
- `importador.py`: carga y **resincroniza** el mapa con reglas explícitas (ver más abajo). Informe detallado de cada importación.
- `main.py`: API REST pública (capas, puntos con filtros, ficha, cercanos, rutas, QR, GeoJSON, exportación) y API del panel (protegida con clave).
- `db.py`: modelo de datos en SQLite (capas, puntos, recursos, rutas, aportaciones, importaciones).

**App móvil web** (`cliente/`): PWA instalable en el móvil, con Leaflet y OpenStreetMap.
- Mapa con las 5 capas filtrables (chips) y marcadores con el color de cada capa.
- **Línea del tiempo**: deslizador y botón ▶ que va «construyendo» el barrio desde hace 450.000 años hasta 2025.
- **Ficha** de cada punto: fotos con su autoría, audioguía, descripción, botones a los juegos del Arcade, enlaces, rutas en las que aparece y **recuerdos del vecindario**.
- **Comparte un recuerdo**: formulario con consentimiento, que llega a la cola de moderación.
- **Rutas a pie** (3): recorrido numerado en el mapa, distancia y tiempo.
- **Cerca de mí**: puntos más cercanos y **geovalla** (aviso al pasar a menos de 40 m), con «pasaporte» de lugares visitados.
- **Vista de lista**: alternativa accesible al mapa.
- **Sin conexión**: la app y los datos ya vistos siguen funcionando (service worker).
- Compartir y **código QR** de cada punto.

**Panel editorial** (`admin/`): resumen de la calidad del contenido, edición de puntos (título, título corto, fecha, posición, descripción, publicar u ocultar), recursos multimedia, **moderación de aportaciones**, **reimportación de My Maps con informe** y hoja de **códigos QR imprimible** para las placas.

## Qué se ha validado y qué ha salido a la luz

### Sobre los datos de My Maps

| Hallazgo | Consecuencia para el proyecto |
|---|---|
| El KML se exporta bien: 21 puntos, 5 capas y 7 fotos. Las coordenadas vienen como **longitud, latitud** | Error típico al importar; hay una prueba que lo vigila |
| **My Maps no tiene campo de fecha.** Las fechas están dentro del texto, en 5 formatos: «(1924)», «(1000 a.C.)», «hace 450.000 años», «… 1958» o mezcladas en la frase | El importador deduce 16 de 21. **2 salen mal** (cogía el primer año del texto) y **5 no tienen fecha**. El modelo necesita un campo de fecha y saber **de dónde salió** (`fecha_metodo`) |
| **Las URL de las fotos cambian en cada exportación** (las antiguas siguen funcionando, de momento) | No sirven como identificador. Las fotos se reconocen por su posición en el punto y conviene **copiarlas a almacenamiento propio** (`--descargar-imagenes`, después S3 en la línea de ASIR) |
| Los títulos traen saltos de línea y son largos («Inauguración de la Gran Vía de Villaverde: la gran arteria que conecta…»); los nombres de capa también | Hacen falta **título corto** y **nombre corto de capa**: datos editoriales que My Maps no puede guardar |
| El identificador sacado del título es frágil: si la Mesa cambia un título, el punto «desaparece» | Cada punto tiene un **identificador propio y estable** (el de las URL y los QR). Un punto renombrado se reconoce por estar en el mismo sitio (menos de 25 m) |
| Las pruebas destaparon un fallo: al renombrar un punto en My Maps, perdía sus recursos editoriales (la audioguía) | Corregido: el contenido editorial se asocia al identificador estable, no al título |
| Si la Mesa corrige algo en el panel y luego cambia el mapa en My Maps | Lo corregido en el panel **no se pisa**: la importación informa del **conflicto**. Un punto borrado en My Maps **no se borra**: se marca |

### Sobre el contenido (para revisar con la Mesa Comunitaria)

- **Los 3 espacios naturales no tienen descripción.** En la app se invita a aportar recuerdos.
- **TRANSFESA:** el mapa dice **1958**; la descripción del yacimiento del proyecto, **1957**. Hay que corregir uno de los dos (también afecta a *Ordena la historia*).
- **El Estanque de Tormentas (2006-2007) no está en el mapa**, y es el hallazgo más importante (el colmillo de casi 4 m). Habría que añadirlo, con sus coordenadas.
- **Fechas a revisar:** «Las fábricas eran vecinas» y «Primera pasarela» no tienen fecha; en 5 puntos la fecha se dedujo del primer año del texto.
- **Erratas en el mapa original:** «preneandernedales», «Bosque Metrapolitano», «inauguraciòn».
- **Fotos:** ninguna tiene autoría ni licencia. Hay que confirmarlas antes de publicar.

### Sobre la técnica

| Hallazgo | Consecuencia |
|---|---|
| Con peticiones simultáneas (el navegador pide capas y puntos a la vez) **SQLite fallaba por usar la conexión desde otro hilo**. Las pruebas automáticas no lo veían porque hacen las peticiones de una en una | Corregido y con una prueba de concurrencia contra el servidor real. Buen caso para clase |
| **La geolocalización y el modo sin conexión solo funcionan con HTTPS** (o en `localhost`). Desde un móvil por `http://IP:8090` no funcionan | **Dependencia directa de la línea de ASIR**: hace falta HTTPS para probar en la calle. Mientras tanto, `?simular=1` |
| Las teselas de OpenStreetMap valen para un prototipo, pero su política de uso no permite una app con mucho tráfico | Decidir proveedor: teselas propias, un proveedor con cuota gratuita o Google Maps SDK (clave de API y coste) |
| La exportación `GET /api/exportar/hitos.csv` genera directamente el CSV de *Ordena la historia* (16 hitos con fecha) | **El contrato entre líneas funciona**: el Arcade de SMR puede alimentarse de la plataforma de DAM |
| Análisis de accesibilidad (axe, WCAG 2 A/AA) de la app y el panel | Sin fallos graves tras corregir el contraste del ocre |
| Los QR generados se leen y abren la ficha. Detrás de un proxy HTTPS, la URL sale con `https://` | Listos para placas cuando haya dominio |

## Pruebas

```bash
cd servidor && python -m pytest -q                   # 36 pruebas: KML, importación, API, panel, concurrencia
python pruebas_navegador/recorrido.py http://localhost:8000 [axe.min.js]
```

El recorrido en navegador (25 comprobaciones) hace lo que haría la gente. Un vecino envía un recuerdo desde el móvil, la Mesa entra en el panel y lo aprueba, y el recuerdo aparece en la ficha. Además, se edita un punto, se reimporta el mapa y se comprueba el conflicto, se lee un QR, se simula la geovalla, se recorre una ruta, se prueba sin conexión y se analiza la accesibilidad.

## Actualizar desde My Maps

```bash
python -m app.importador --kml-url "https://www.google.com/maps/d/kml?mid=1KayNHx_ZIswUM1Akaocl6aCpxf5LtN8&forcekml=1"
python -m app.importador --descargar-imagenes      # copia las fotos a media/kml/
python -m app.importador --listar                  # identificadores para enriquecimiento.json
```

También desde el panel, pestaña *Importar de My Maps*. El contenido que My Maps no puede guardar (fechas corregidas, títulos cortos, rutas, enlaces al Arcade, audioguías) está en `servidor/datos/enriquecimiento.json`.

## Decisiones pendientes

1. **¿Dónde edita la Mesa?** El prototipo es híbrido: My Maps sigue siendo la fuente de los puntos y el servidor añade y protege lo demás. La otra opción es importar una vez y editar solo en el panel (más simple y robusto).
2. **¿App nativa o web?** Los RA de *Programación multimedia y dispositivos móviles* piden una app para dispositivos móviles. Propuesta: el alumnado de DAM hace una **app nativa (Android/Kotlin o Flutter)** contra **esta misma API** (el contrato está en `/openapi.json`), y la PWA queda como referencia y como versión web.
3. **Proveedor de mapas** (ver arriba).
4. **Derechos:** autoría de las fotos y consentimiento para grabar testimonios (audioguías reales).

La audioguía de *La Copa de Villaverde* es una **voz sintética de prueba** (`herramientas/generar_audioguia.py`): solo sirve para validar el reproductor.

## Estructura

```
mapa_vivo_butarque/
├── servidor/
│   ├── app/            config, db, kml, importador, geo, main (API)
│   ├── datos/          mapa_butarque.kml (exportación del 9-10-2026) · enriquecimiento.json
│   ├── media/audio/    audioguía de prueba
│   ├── herramientas/   generar_audioguia.py
│   ├── tests/          36 pruebas
│   └── requirements.txt
├── cliente/            app móvil web (PWA): index.html, app.js, estilos.css, sw.js, Leaflet incluido
├── admin/              panel editorial
├── pruebas_navegador/  recorrido.py (Playwright)
├── Dockerfile · compose.yaml
```
