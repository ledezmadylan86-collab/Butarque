"""
Peticiones simultáneas contra el servidor real (uvicorn), como hace el navegador al arrancar.
Esta prueba existe porque el cliente de pruebas de FastAPI hace las peticiones de una en una
y no detectaba un fallo de SQLite con varios hilos.
"""

import socket
import threading
import time
from concurrent.futures import ThreadPoolExecutor

import httpx
import uvicorn


def _puerto_libre():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def test_peticiones_en_paralelo(entorno):
    from app.main import app
    puerto = _puerto_libre()
    servidor = uvicorn.Server(uvicorn.Config(app, port=puerto, log_level="warning"))
    hilo = threading.Thread(target=servidor.run, daemon=True)
    hilo.start()
    base = f"http://127.0.0.1:{puerto}"
    for _ in range(50):
        try:
            if httpx.get(base + "/api/salud").status_code == 200:
                break
        except httpx.HTTPError:
            time.sleep(0.1)
    rutas = ["/api/capas", "/api/puntos", "/api/rutas", "/api/puntos/la-copa-de-villaverde", "/api/rutas/ruta-vecinal"] * 8
    with ThreadPoolExecutor(max_workers=10) as pool:
        codigos = list(pool.map(lambda r: httpx.get(base + r).status_code, rutas))
    servidor.should_exit = True
    hilo.join(timeout=5)
    assert codigos == [200] * len(rutas)
