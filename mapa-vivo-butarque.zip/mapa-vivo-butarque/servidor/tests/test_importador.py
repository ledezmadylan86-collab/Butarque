"""
Reimportaciones: qué pasa cuando la Mesa Comunitaria cambia el mapa en My Maps.
Cada prueba modifica el KML real como lo haría alguien editándolo.
"""

import http.server
import threading

from app.db import conectar, crear_esquema
from app.importador import cargar_enriquecimiento, importar
from conftest import KML_REAL

ENR = cargar_enriquecimiento()


def nueva_bd(tmp_path):
    conn = conectar(tmp_path / "m.db")
    crear_esquema(conn)
    return conn


def test_primera_importacion(tmp_path):
    conn = nueva_bd(tmp_path)
    inf = importar(conn, KML_REAL, ENR)
    assert len(inf["nuevos"]) == 21 and not inf["conflictos"]
    # identificadores propios del fichero editorial
    assert conn.execute("SELECT titulo FROM puntos WHERE id = 'mamut-transfesa'").fetchone()[0] == 'Descubrimiento "Mamut" en TRANSFESA'
    # la fecha editorial corrige a la deducida del texto ("2001" era el primer año que aparecía)
    f = conn.execute("SELECT anio, fecha_texto, fecha_metodo FROM puntos WHERE id = 'el-nuevo-butarque'").fetchone()
    assert tuple(f) == (1999, "1999-2007", "editorial")
    # recursos del Arcade con la URL configurada
    urls = [r[0] for r in conn.execute("SELECT url FROM recursos WHERE tipo = 'juego'")]
    assert "https://arcade.ejemplo/excavacion/" in [u.replace("http://127.0.0.1:8080", "https://arcade.ejemplo") for u in urls]
    assert conn.execute("SELECT COUNT(*) FROM ruta_paradas").fetchone()[0] == 16


def test_reimportar_sin_cambios_no_duplica(tmp_path):
    conn = nueva_bd(tmp_path)
    importar(conn, KML_REAL, ENR)
    inf = importar(conn, KML_REAL, ENR)
    assert len(inf["sin_cambios"]) == 21
    assert conn.execute("SELECT COUNT(*) FROM puntos").fetchone()[0] == 21
    assert conn.execute("SELECT COUNT(*) FROM recursos WHERE origen = 'kml'").fetchone()[0] == 7


def test_urls_de_fotos_cambian_en_cada_exportacion(tmp_path):
    """My Maps genera otra URL para la misma foto en cada exportación."""
    conn = nueva_bd(tmp_path)
    importar(conn, KML_REAL, ENR)
    otra = KML_REAL.replace("hostedimage/m/*/3AAj", "hostedimage/m/*/3BBj")
    inf = importar(conn, otra, ENR)
    assert inf["imagenes"]["url_cambiada"] == 7 and inf["imagenes"]["nuevas"] == 0
    assert conn.execute("SELECT COUNT(*) FROM recursos WHERE origen = 'kml'").fetchone()[0] == 7


def test_cambio_de_titulo_en_my_maps_conserva_el_identificador(tmp_path):
    conn = nueva_bd(tmp_path)
    importar(conn, KML_REAL, ENR)
    otro = KML_REAL.replace("<name>La Copa de Villaverde</name>", "<name>La Copa de Villaverde (depósito de agua de MZA)</name>")
    inf = importar(conn, otro, ENR)
    assert inf["renombrados"] == [{"id": "la-copa-de-villaverde", "antes": "La Copa de Villaverde",
                                   "ahora": "La Copa de Villaverde (depósito de agua de MZA)"}]
    assert conn.execute("SELECT COUNT(*) FROM puntos").fetchone()[0] == 21
    # el audio y los demás recursos siguen enganchados al mismo punto
    assert conn.execute("SELECT COUNT(*) FROM recursos WHERE punto_id = 'la-copa-de-villaverde' AND tipo = 'audio'").fetchone()[0] == 1


def test_lo_editado_en_el_panel_no_se_pisa(tmp_path):
    conn = nueva_bd(tmp_path)
    importar(conn, KML_REAL, ENR)
    conn.execute("UPDATE puntos SET descripcion = 'Texto revisado por la Mesa', editado_localmente = 1 WHERE id = 'yacimiento-de-las-camas'")
    conn.commit()
    otro = KML_REAL.replace("La excavación del 2004", "La excavación de 2004")
    inf = importar(conn, otro, ENR)
    assert inf["conflictos"][0]["id"] == "yacimiento-de-las-camas"
    assert conn.execute("SELECT descripcion FROM puntos WHERE id = 'yacimiento-de-las-camas'").fetchone()[0] == "Texto revisado por la Mesa"


def test_punto_borrado_en_my_maps_no_se_borra_aqui(tmp_path):
    conn = nueva_bd(tmp_path)
    importar(conn, KML_REAL, ENR)
    inicio = KML_REAL.index("<Placemark>\n        <name>Bosque Miyawaki")
    fin = KML_REAL.index("</Placemark>", inicio) + len("</Placemark>")
    inf = importar(conn, KML_REAL[:inicio] + KML_REAL[fin:], ENR)
    assert inf["desaparecidos"] == ["bosque-miyawaki"]
    assert tuple(conn.execute("SELECT en_kml, publicado FROM puntos WHERE id = 'bosque-miyawaki'").fetchone()) == (0, 1)


def test_punto_movido_en_my_maps_se_actualiza(tmp_path):
    conn = nueva_bd(tmp_path)
    importar(conn, KML_REAL, ENR)
    inf = importar(conn, KML_REAL.replace("-3.674144,40.3466645,0", "-3.674244,40.3467645,0"), ENR)
    assert inf["actualizados"] == [{"id": "huerto-urbano-butarque", "campos": ["lat", "lon"]}]


def test_kml_roto_no_deja_la_base_a_medias(tmp_path):
    conn = nueva_bd(tmp_path)
    importar(conn, KML_REAL, ENR)
    try:
        importar(conn, KML_REAL[:5000], ENR)
    except Exception:
        pass
    assert conn.execute("SELECT COUNT(*) FROM puntos").fetchone()[0] == 21


def test_descargar_imagenes(tmp_path):
    """Las fotos se copian a media/ para no depender de los enlaces de Google."""
    (tmp_path / "web").mkdir()
    (tmp_path / "web" / "foto.jpg").write_bytes(b"\xff\xd8\xff\xe0JPEG")

    class Silencioso(http.server.SimpleHTTPRequestHandler):
        def __init__(self, *a, **k):
            super().__init__(*a, directory=str(tmp_path / "web"), **k)

        def log_message(self, *a):
            pass

    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Silencioso)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    url = f"http://127.0.0.1:{srv.server_address[1]}/foto.jpg"
    kml = KML_REAL
    import re
    kml = re.sub(r"https://mymaps\.usercontent\.google\.com/hostedimage/[^\"\]<]+", url, kml)
    conn = nueva_bd(tmp_path)
    inf = importar(conn, kml, ENR, descargar_imagenes=True, media_dir=tmp_path / "media")
    srv.shutdown()
    assert inf["imagenes"]["descargadas"] == 7 and not inf["imagenes"]["errores"]
    assert (tmp_path / "media" / "kml" / "la-copa-de-villaverde-1.jpg").read_bytes().startswith(b"\xff\xd8")
    assert conn.execute("SELECT url FROM recursos WHERE punto_id = 'la-copa-de-villaverde' AND tipo = 'imagen'").fetchone()[0] \
        == "/media/kml/la-copa-de-villaverde-1.jpg"
