"""API pública, aportaciones vecinales y panel editorial."""

import csv
import io


def test_arranque_importa_el_mapa(cliente):
    assert cliente.get("/api/salud").json() == {"estado": "ok", "puntos": 21}
    capas = cliente.get("/api/capas").json()
    assert [c["puntos"] for c in capas] == [5, 4, 3, 6, 3]


def test_lista_y_filtros(cliente):
    todos = cliente.get("/api/puntos").json()
    assert len(todos) == 21
    assert todos[0]["id"] == "los-habitantes-prehistoricos"          # ordenados por fecha
    assert {"lat", "lon", "color", "miniatura", "tiene_audio", "tiene_juego"} <= todos[0].keys()
    industria = cliente.get("/api/puntos", params={"capa": "industrias-y-tejido-productivo"}).json()
    assert len(industria) == 4
    hasta_1900 = cliente.get("/api/puntos", params={"hasta": 1900}).json()
    con_fecha = [p for p in hasta_1900 if p["anio"] is not None]
    assert [p["anio"] for p in con_fecha] == [-450000, -1000, 1771, 1851]
    assert len(hasta_1900) == 4 + 5                                    # + los 5 sin fecha
    assert len(cliente.get("/api/puntos", params={"texto": "Platanera"}).json()) == 2


def test_ficha_completa(cliente):
    p = cliente.get("/api/puntos/la-copa-de-villaverde").json()
    assert p["capa"]["nombre"] == "Industrias y tejido productivo"
    assert [r["tipo"] for r in p["recursos"]] == ["imagen", "audio"]
    assert p["url"].endswith("/p/la-copa-de-villaverde")
    assert p["rutas"][0]["id"] == "ruta-industrial"
    assert cliente.get("/api/puntos/no-existe").status_code == 404


def test_cercanos_y_rutas(cliente):
    cerca = cliente.get("/api/cercanos", params={"lat": 40.3505, "lon": -3.6814, "radio": 300}).json()
    assert cerca[0]["id"] == "la-copa-de-villaverde" and cerca[0]["distancia_m"] < 10
    rutas = cliente.get("/api/rutas").json()
    assert {r["id"]: r["paradas"] for r in rutas} == {"ruta-industrial": 5, "ruta-prehistoria": 4, "ruta-vecinal": 7}
    vecinal = cliente.get("/api/rutas/ruta-vecinal").json()
    assert 1500 < vecinal["distancia_m"] < 4000 and vecinal["minutos"] > 15
    assert "tramo_m" not in vecinal["paradas"][0] and vecinal["paradas"][1]["tramo_m"] > 0


def test_qr_y_geojson(cliente):
    r = cliente.get("/api/puntos/mamut-transfesa/qr.png")
    assert r.status_code == 200 and r.content.startswith(b"\x89PNG")
    g = cliente.get("/api/puntos.geojson").json()
    assert len(g["features"]) == 21 and g["features"][0]["geometry"]["coordinates"][0] < 0   # [lon, lat]


def test_exportar_hitos_para_ordena_la_historia(cliente):
    filas = list(csv.DictReader(io.StringIO(cliente.get("/api/exportar/hitos.csv").text)))
    assert len(filas) == 16
    assert {"id", "anio", "fecha_texto", "titulo", "descripcion", "foto"} <= filas[0].keys()   # columnas del juego
    copa = next(f for f in filas if f["id"] == "la-copa-de-villaverde")
    assert copa["foto"] == "la-copa-de-villaverde.jpg" and copa["foto_url"].startswith("https://")
    assert all(len(f["descripcion"]) <= 241 for f in filas)


def test_aportacion_moderada(cliente, admin_h):
    envio = {"nombre": "Vecina de Los Rosales", "texto": "Mi padre trabajó en la Standard Eléctrica desde 1965.", "consentimiento": True}
    r = cliente.post("/api/puntos/desarrollo-industrial-ii/aportaciones", json=envio)
    assert r.status_code == 202
    assert cliente.get("/api/puntos/desarrollo-industrial-ii").json()["recuerdos"] == []      # aún no se ve
    pendientes = cliente.get("/api/admin/aportaciones", headers=admin_h).json()
    assert len(pendientes) == 1
    cliente.post(f"/api/admin/aportaciones/{pendientes[0]['id']}/aprobar", headers=admin_h)
    recuerdos = cliente.get("/api/puntos/desarrollo-industrial-ii").json()["recuerdos"]
    assert recuerdos[0]["nombre"] == "Vecina de Los Rosales"


def test_aportaciones_validacion_y_abuso(cliente, admin_h):
    url = "/api/puntos/la-gran-valla/aportaciones"
    r = cliente.post(url, json={"texto": "corto", "consentimiento": True})
    assert r.status_code == 422 and r.json()["detail"][0]["msg"] == "El texto debe tener al menos 10 caracteres"
    assert cliente.post(url, json={"texto": "Un texto suficientemente largo", "consentimiento": False}).status_code == 422
    assert cliente.post(url, json={"texto": "Un texto de robot muy largo", "consentimiento": True, "web": "spam"}).status_code == 202
    assert cliente.get("/api/admin/aportaciones", headers=admin_h).json() == []     # el robot no entra en la cola
    codigos = [cliente.post(url, json={"texto": f"Recuerdo número {i} del barrio", "consentimiento": True}).status_code for i in range(7)]
    assert codigos[:5] == [202] * 5 and codigos[5:] == [429, 429]


def test_panel_exige_clave(cliente):
    assert cliente.get("/api/admin/resumen").status_code == 401
    assert cliente.get("/api/admin/resumen", headers={"Authorization": "Bearer mala"}).status_code == 401


def test_edicion_protege_frente_a_reimportacion(cliente, admin_h):
    r = cliente.put("/api/admin/puntos/paseo-fluvial-manzanares", headers=admin_h,
                    json={"descripcion": "Recorrido junto al río, tras su renaturalización.", "anio": 2011, "fecha_texto": "2011"})
    assert r.status_code == 200 and r.json()["editado_localmente"] == 1 and r.json()["fecha_metodo"] == "editorial"
    inf = cliente.post("/api/admin/importar", headers=admin_h).json()
    # My Maps sigue sin descripción: se informa del conflicto y se conserva la versión del panel
    assert inf["conflictos"] == [{"id": "paseo-fluvial-manzanares", "campos": ["descripcion"],
                                  "detalle": "Editado en el panel: se conserva la versión local"}]
    p = cliente.get("/api/puntos/paseo-fluvial-manzanares").json()
    assert p["anio"] == 2011 and p["descripcion"].startswith("Recorrido junto al río")


def test_edicion_validaciones(cliente, admin_h):
    assert cliente.put("/api/admin/puntos/bosque-miyawaki", headers=admin_h, json={"lat": 41.5}).status_code == 422   # fuera del barrio
    assert cliente.put("/api/admin/puntos/bosque-miyawaki", headers=admin_h, json={"capa_id": "no-existe"}).status_code == 422
    r = cliente.put("/api/admin/puntos/bosque-miyawaki", headers=admin_h, json={"publicado": False})
    assert r.json()["publicado"] == 0
    assert cliente.get("/api/puntos/bosque-miyawaki").status_code == 404
    assert len(cliente.get("/api/puntos").json()) == 20


def test_recursos_propios(cliente, admin_h):
    nuevo = {"tipo": "video", "titulo": "Entrevista", "url": "https://ejemplo.org/v.mp4", "autoria": "Alumnado DAM"}
    r = cliente.post("/api/admin/puntos/centro-de-salud/recursos", headers=admin_h, json=nuevo)
    assert r.status_code == 201
    assert cliente.post("/api/admin/puntos/centro-de-salud/recursos", headers=admin_h,
                        json=nuevo | {"url": "javascript:alert(1)"}).status_code == 422
    assert cliente.delete(f"/api/admin/recursos/{r.json()['id']}", headers=admin_h).status_code == 204
    foto_kml = cliente.get("/api/admin/puntos/la-copa-de-villaverde", headers=admin_h).json()["recursos"][0]
    assert cliente.delete(f"/api/admin/recursos/{foto_kml['id']}", headers=admin_h).status_code == 409


def test_enlace_directo_y_cliente(cliente):
    r = cliente.get("/p/mamut-transfesa")
    assert r.status_code == 200 and "text/html" in r.headers["content-type"]
    assert cliente.get("/").status_code == 200
    assert cliente.get("/media/audio/la-copa-de-villaverde.mp3").status_code in (200, 404)
    assert cliente.get("/openapi.json").json()["info"]["title"].startswith("Mapa vivo")
