"""Lectura del KML de My Maps y extracción de fechas."""

import pytest

from app.kml import color_de_estilo, extraer_fecha, html_a_texto, leer_kml, slug
from conftest import KML_REAL


def test_kml_real_tiene_las_5_capas_y_21_puntos():
    d = leer_kml(KML_REAL)
    assert d["nombre"] == "Geolocalizacion Linea del tiempo"
    assert [c["nombre"] for c in d["capas"]] == [
        "Yacimientos arqueológicos y vestigios históricos", "Industrias y tejido productivo",
        "Movimientos vecinales y vida en el barrio", "Equipamientos e infraestructuras", "Espacios Naturales"]
    assert len(d["puntos"]) == 21
    assert sum(len(p["imagenes"]) for p in d["puntos"]) == 7


def test_coordenadas_en_orden_latitud_longitud():
    """El KML guarda longitud,latitud: es el error más típico al importarlo."""
    for p in leer_kml(KML_REAL)["puntos"]:
        assert 40.33 < p["lat"] < 40.36 and -3.69 < p["lon"] < -3.67, p["titulo"]


def test_titulos_con_saltos_de_linea_se_normalizan():
    titulos = [p["titulo"] for p in leer_kml(KML_REAL)["puntos"]]
    assert "El parque junto al CEIP El Greco, un nuevo espacio de encuentro para el barrio" in titulos
    assert all("\n" not in t and "  " not in t for t in titulos)


def test_descripcion_sin_html_y_con_parrafos():
    t = html_a_texto('<img src="x.jpg" height="200"/><br><br>Primera frase<br>sigue aquí.<br><br>Segundo &amp; párrafo')
    assert t == "Primera frase sigue aquí.\n\nSegundo & párrafo"


@pytest.mark.parametrize("texto, esperado", [
    ("... desde el Pleistoceno, hace 450.000 años: ciervos", (-450000, "hace 450.000 años", "hace_n_anios")),
    ("producción alfarera y metalúrgica. (1000 a.C.)", (-1000, "1000 a. C.", "antes_de_cristo")),
    ("Standard Electric (teléfonos, 1962), Marconi ... al barrio. (1960)", (1960, "1960", "parentesis")),
    ("se denominan así actividades populares. 1958", (1958, "1958", "final_del_texto")),
    ("Cuando el 4 de diciembre de 1986 un grupo de vecinos", (1986, "1986", "primer_anio")),
    ("Sin ninguna fecha en el texto", (None, None, None)),
    ("", (None, None, None)),
])
def test_extraer_fecha(texto, esperado):
    assert extraer_fecha(texto) == esperado


def test_slug_y_color():
    assert slug('Descubrimiento "Mamut" en TRANSFESA') == "descubrimiento-mamut-en-transfesa"
    assert slug("Huerto Urbano de Butarque - HUB-") == "huerto-urbano-de-butarque-hub"
    assert len(slug("palabra " * 30)) <= 50
    assert color_de_estilo("#icon-1899-558B2F-nodesc") == "#558B2F"
    assert color_de_estilo("#otro") == "#7F7F7F"


def test_kml_que_no_es_de_my_maps():
    with pytest.raises(Exception):
        leer_kml("<html>esto no es un kml</html>")
