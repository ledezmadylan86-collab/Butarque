import os
import sys
from pathlib import Path

import pytest

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ))
os.environ.setdefault("ADMIN_TOKEN", "clave-de-pruebas")

from app import config  # noqa: E402

KML_REAL = (RAIZ / "datos" / "mapa_butarque.kml").read_text(encoding="utf-8")


@pytest.fixture
def entorno(tmp_path, monkeypatch):
    """Base de datos y multimedia nuevas para cada prueba."""
    monkeypatch.setattr(config, "DB", tmp_path / "mapa.db")
    monkeypatch.setattr(config, "MEDIA", tmp_path / "media")
    monkeypatch.setattr(config, "ADMIN_TOKEN", "clave-de-pruebas")
    monkeypatch.setattr(config, "ARCADE_URL", "https://arcade.ejemplo")
    return tmp_path


@pytest.fixture
def cliente(entorno):
    from fastapi.testclient import TestClient
    from app.main import _envios, app
    _envios.clear()                         # el límite de envíos por IP no se arrastra entre pruebas
    with TestClient(app) as c:              # el arranque importa el KML real
        yield c


@pytest.fixture
def admin_h():
    return {"Authorization": "Bearer clave-de-pruebas"}
