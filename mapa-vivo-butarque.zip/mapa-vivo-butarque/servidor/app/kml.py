"""
Lectura del KML que exporta Google My Maps.

My Maps exporta cada capa como una <Folder> y cada punto como un <Placemark> con:
  - <name>          título (a veces con saltos de línea y espacios sobrantes)
  - <description>   HTML sencillo: <br> para los saltos y <img> con la foto
  - <styleUrl>      el estilo, que lleva el color de la capa: "#icon-1899-E65100"
  - <ExtendedData>  gx_media_links: las URL de las fotos
  - <coordinates>   "longitud,latitud,altitud"  (¡primero la longitud!)

Este módulo no sabe nada de la base de datos: convierte el KML en una lista de
diccionarios limpios. Así se puede probar por separado.
"""

import html
import re
import unicodedata
import xml.etree.ElementTree as ET

NS = {"k": "http://www.opengis.net/kml/2.2"}
COLOR_POR_DEFECTO = "#7F7F7F"


# --------------------------------------------------------------------------- utilidades de texto
def normalizar_espacios(texto):
    """'El parque junto al CEIP \\nEl Greco' -> 'El parque junto al CEIP El Greco'"""
    return re.sub(r"\s+", " ", texto or "").strip()


def slug(texto, maximo=50):
    """Identificador legible para URL y códigos QR: 'Descubrimiento "Mamut"' -> 'descubrimiento-mamut'."""
    texto = unicodedata.normalize("NFKD", normalizar_espacios(texto)).encode("ascii", "ignore").decode()
    texto = re.sub(r"[^a-z0-9]+", "-", texto.lower()).strip("-")
    if len(texto) > maximo:                        # cortar por una palabra completa
        texto = texto[:maximo].rsplit("-", 1)[0]
    return texto or "punto"


def html_a_texto(descripcion):
    """Quita las imágenes y etiquetas del HTML de My Maps y conserva los párrafos."""
    if not descripcion:
        return ""
    t = re.sub(r"<img[^>]*>", "", descripcion, flags=re.I)
    t = re.sub(r"<br\s*/?>", "\n", t, flags=re.I)
    t = re.sub(r"<[^>]+>", "", t)
    t = html.unescape(t)
    # Los saltos de My Maps suelen cortar frases a mitad (vienen de copiar un PDF):
    # un salto simple se convierte en espacio; dos o más, en párrafo.
    parrafos = [normalizar_espacios(p) for p in re.split(r"\n\s*\n", t)]
    return "\n\n".join(p for p in parrafos if p)


def color_de_estilo(style_url):
    """'#icon-1899-E65100-nodesc' -> '#E65100'"""
    m = re.search(r"-([0-9A-Fa-f]{6})(?:-|$)", style_url or "")
    return f"#{m.group(1).upper()}" if m else COLOR_POR_DEFECTO


# --------------------------------------------------------------------------- fechas
def extraer_fecha(texto):
    """
    Propone el año del hito a partir del texto de My Maps, que no tiene un campo de fecha.
    Devuelve (anio, fecha_texto, metodo) o (None, None, None).

    Orden de las reglas (de más fiable a menos):
      1. "hace 450.000 años"             -> -450000
      2. "(1000 a.C.)"                   -> -1000
      3. "(1924)" entre paréntesis       -> 1924   (convención de la Mesa al final del texto)
      4. un año suelto al final: "... 1958"
      5. el primer año que aparezca      -> poco fiable: lo marca para revisión editorial
    """
    if not texto:
        return None, None, None
    m = re.search(r"hace\s+([\d.]+)\s+años", texto, re.I)
    if m:
        n = int(m.group(1).replace(".", ""))
        return -n, f"hace {m.group(1)} años", "hace_n_anios"
    m = re.search(r"\(\s*(\d{1,5})\s*a\.?\s*C\.?\s*\)", texto)
    if m:
        n = int(m.group(1))
        return -n, f"{n} a. C.", "antes_de_cristo"
    m = re.search(r"\((1[5-9]\d\d|20\d\d)\)", texto)
    if m:
        return int(m.group(1)), m.group(1), "parentesis"
    m = re.search(r"\b(1[5-9]\d\d|20\d\d)\s*\.?\s*$", texto)
    if m:
        return int(m.group(1)), m.group(1), "final_del_texto"
    m = re.search(r"\b(1[5-9]\d\d|20\d\d)\b", texto)
    if m:
        return int(m.group(1)), m.group(1), "primer_anio"
    return None, None, None


# --------------------------------------------------------------------------- lectura
def leer_kml(contenido):
    """
    contenido: texto o bytes del KML.
    Devuelve {"nombre": nombre del mapa, "capas": [...], "puntos": [...]}.
    """
    if isinstance(contenido, str):
        contenido = contenido.encode("utf-8")
    raiz = ET.fromstring(contenido)
    doc = raiz.find("k:Document", NS)
    if doc is None:
        raise ValueError("El fichero no es un KML de My Maps (no tiene <Document>)")

    resultado = {"nombre": normalizar_espacios(doc.findtext("k:name", "", NS)), "capas": [], "puntos": []}
    carpetas = doc.findall("k:Folder", NS) or [doc]          # un mapa sin capas tiene los puntos sueltos
    for orden_capa, carpeta in enumerate(carpetas):
        nombre_capa = normalizar_espacios(carpeta.findtext("k:name", "Sin capa", NS))
        colores = []
        for orden, p in enumerate(carpeta.findall("k:Placemark", NS)):
            coords = (p.findtext(".//k:Point/k:coordinates", "", NS) or "").strip()
            if not coords:
                continue                                       # líneas y polígonos: fuera del prototipo
            lon, lat = (float(x) for x in coords.split(",")[:2])
            descripcion_html = p.findtext("k:description", "", NS)
            imagenes = [normalizar_espacios(v.text) for v in p.findall(".//k:Data[@name='gx_media_links']/k:value", NS) if v.text]
            if not imagenes:                                   # algunos exportes solo traen el <img>
                imagenes = re.findall(r'<img[^>]+src="([^"]+)"', descripcion_html or "")
            color = color_de_estilo(p.findtext("k:styleUrl", "", NS))
            colores.append(color)
            titulo = normalizar_espacios(p.findtext("k:name", "", NS))
            descripcion = html_a_texto(descripcion_html)
            anio, fecha_texto, metodo = extraer_fecha(descripcion)
            resultado["puntos"].append({
                "kml_nombre": titulo,
                "titulo": titulo,
                "slug": slug(titulo),
                "capa": nombre_capa,
                "orden": orden,
                "lat": lat,
                "lon": lon,
                "color": color,
                "descripcion": descripcion,
                "imagenes": imagenes,
                "anio": anio,
                "fecha_texto": fecha_texto,
                "fecha_metodo": metodo,
            })
        # el color de la capa es el más frecuente entre sus puntos
        color_capa = max(set(colores), key=colores.count) if colores else COLOR_POR_DEFECTO
        resultado["capas"].append({"nombre": nombre_capa, "slug": slug(nombre_capa), "color": color_capa, "orden": orden_capa})
    return resultado
