"""Configuración por variables de entorno (las mismas que se pasan al contenedor)."""

import os
import secrets
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent            # carpeta servidor/
PROYECTO = RAIZ.parent                                    # carpeta mapa_vivo_butarque/

# Base de datos SQLite. En el contenedor vive en un volumen para no perderla al reconstruir.
DB = Path(os.environ.get("MAPA_DB", RAIZ / "instancia" / "mapa.db"))

# Ficheros de partida
KML = Path(os.environ.get("MAPA_KML", RAIZ / "datos" / "mapa_butarque.kml"))
ENRIQUECIMIENTO = Path(os.environ.get("MAPA_ENRIQUECIMIENTO", RAIZ / "datos" / "enriquecimiento.json"))

# Multimedia propia (audios, imágenes descargadas). Se sirve en /media
MEDIA = Path(os.environ.get("MAPA_MEDIA", RAIZ / "media"))

# Clientes estáticos
CLIENTE = Path(os.environ.get("MAPA_CLIENTE", PROYECTO / "cliente"))
ADMIN = Path(os.environ.get("MAPA_ADMIN", PROYECTO / "admin"))

# Dirección pública del Arcade de Butarque (línea de SMR), para los enlaces a los juegos
ARCADE_URL = os.environ.get("ARCADE_URL", "http://127.0.0.1:8080").rstrip("/")

# Dirección pública de esta app, para los códigos QR. Vacía = la que use quien hace la petición.
URL_PUBLICA = os.environ.get("URL_PUBLICA", "").rstrip("/")

# Clave del panel editorial. Si no se define, se inventa una al arrancar y se muestra en el log.
ADMIN_TOKEN = os.environ.get("ADMIN_TOKEN") or secrets.token_urlsafe(16)
ADMIN_TOKEN_GENERADO = "ADMIN_TOKEN" not in os.environ

# Aportaciones vecinales: límite por dirección IP
APORTACIONES_MAX = int(os.environ.get("APORTACIONES_MAX", "5"))
APORTACIONES_VENTANA_S = int(os.environ.get("APORTACIONES_VENTANA_S", "600"))
SAL_IP = os.environ.get("SAL_IP", "butarque")             # para guardar la IP solo como huella
