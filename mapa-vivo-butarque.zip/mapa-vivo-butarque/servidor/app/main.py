"""
Servidor de contenidos del «Mapa vivo de Butarque».

Una sola aplicación sirve:
  /api/...        API REST (documentación interactiva en /docs, esquema OpenAPI en /openapi.json)
  /               app móvil web (PWA) que consume la API
  /p/{id}         enlace directo a un punto (el que llevan los códigos QR)
  /admin/         panel editorial para la Mesa Comunitaria
  /media/...      multimedia propia (audios, fotos descargadas)

Arranque:  uvicorn app.main:app --reload      (desde la carpeta servidor/)
"""

import csv
import hashlib
import io
import secrets
import time
from collections import defaultdict, deque
from contextlib import asynccontextmanager
from typing import Literal, Optional

import qrcode
from fastapi import Depends, FastAPI, Header, HTTPException, Query, Request, Response
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import config
from .db import conectar, crear_esquema, filas
from .geo import distancia_m, minutos_a_pie
from .importador import cargar_enriquecimiento, importar


# --------------------------------------------------------------------------- arranque
@asynccontextmanager
async def ciclo_de_vida(app):
    conn = conectar(config.DB)
    crear_esquema(conn)
    if conn.execute("SELECT COUNT(*) FROM puntos").fetchone()[0] == 0 and config.KML.exists():
        informe = importar(conn, config.KML.read_bytes(), cargar_enriquecimiento(), origen=str(config.KML))
        print(f"Primera importación del KML: {len(informe['nuevos'])} puntos")
    conn.close()
    if config.ADMIN_TOKEN_GENERADO:
        print(f"\n  Clave del panel editorial (/admin): {config.ADMIN_TOKEN}\n  (define ADMIN_TOKEN para fijarla)\n")
    yield


app = FastAPI(
    title="Mapa vivo de Butarque · servidor de contenidos",
    version="0.1.0",
    description="API del prototipo de la línea de 2.º DAM del proyecto intermodular Butarque. "
                "Los puntos salen del mapa «Geolocalización Línea del tiempo» de la Mesa Comunitaria (Google My Maps) "
                "y se enriquecen con recursos multimedia, rutas y recuerdos del vecindario.",
    lifespan=ciclo_de_vida,
)

# La API pública se puede consultar desde otras webs (por ejemplo, el Arcade de SMR)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["GET"], allow_headers=["*"])


@app.middleware("http")
async def cabeceras_seguridad(request: Request, call_next):
    r = await call_next(request)
    r.headers["X-Content-Type-Options"] = "nosniff"
    r.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    if request.url.path.startswith("/api/"):
        r.headers.setdefault("Cache-Control", "no-cache")
    return r


MENSAJES = {
    "missing": "es obligatorio",
    "string_too_short": "debe tener al menos {min_length} caracteres",
    "string_too_long": "no puede pasar de {max_length} caracteres",
    "string_pattern_mismatch": "no tiene un formato válido",
    "greater_than_equal": "es demasiado pequeño (mínimo {ge})",
    "less_than_equal": "es demasiado grande (máximo {le})",
    "literal_error": "no es un valor permitido ({expected})",
}
CAMPOS = {"url": "La dirección", "texto": "El texto", "titulo": "El título", "autoria": "La autoría", "lat": "La latitud",
          "lon": "La longitud", "anio": "El año", "consentimiento": "El consentimiento", "tipo": "El tipo", "nombre": "El nombre"}


@app.exception_handler(RequestValidationError)
async def errores_en_castellano(request: Request, exc: RequestValidationError):
    """Mensajes de validación comprensibles para la Mesa Comunitaria y el vecindario."""
    detalle = []
    for e in exc.errors():
        campo = str(e["loc"][-1]) if e.get("loc") else ""
        plantilla = MENSAJES.get(e["type"], "no es válido")
        try:
            texto = plantilla.format(**(e.get("ctx") or {}))
        except (KeyError, IndexError):
            texto = plantilla
        detalle.append({"loc": e.get("loc"), "type": e["type"], "msg": f"{CAMPOS.get(campo, campo.capitalize())} {texto}"})
    return JSONResponse({"detail": detalle}, status_code=422)


def bd():
    conn = conectar(config.DB)
    try:
        yield conn
    finally:
        conn.close()


def admin(authorization: str = Header(default="")):
    """Las rutas del panel exigen la cabecera  Authorization: Bearer <ADMIN_TOKEN>."""
    token = authorization.removeprefix("Bearer ").strip()
    if not secrets.compare_digest(token, config.ADMIN_TOKEN):
        raise HTTPException(401, "Clave del panel incorrecta", headers={"WWW-Authenticate": "Bearer"})


# --------------------------------------------------------------------------- ayudas
def url_publica(request: Request, ruta: str):
    base = config.URL_PUBLICA or str(request.base_url).rstrip("/")
    return f"{base}{ruta}"


def resumen_punto(f):
    return {k: f[k] for k in ("id", "titulo", "titulo_corto", "capa_id", "color", "lat", "lon", "anio", "fecha_texto",
                               "miniatura", "tiene_audio", "tiene_juego") if k in f.keys()}


CONSULTA_RESUMEN = """
SELECT p.*, c.color,
       (SELECT url FROM recursos r WHERE r.punto_id = p.id AND r.tipo = 'imagen' ORDER BY r.orden LIMIT 1) AS miniatura,
       EXISTS (SELECT 1 FROM recursos r WHERE r.punto_id = p.id AND r.tipo = 'audio') AS tiene_audio,
       EXISTS (SELECT 1 FROM recursos r WHERE r.punto_id = p.id AND r.tipo = 'juego') AS tiene_juego
FROM puntos p JOIN capas c ON c.id = p.capa_id
"""


def punto_o_404(conn, pid, solo_publicados=True):
    f = conn.execute(CONSULTA_RESUMEN + " WHERE p.id = ?" + (" AND p.publicado = 1" if solo_publicados else ""), (pid,)).fetchone()
    if f is None:
        raise HTTPException(404, f"No existe el punto «{pid}»")
    return f


# --------------------------------------------------------------------------- API pública
@app.get("/api/salud", tags=["sistema"])
def salud(conn=Depends(bd)):
    return {"estado": "ok", "puntos": conn.execute("SELECT COUNT(*) FROM puntos").fetchone()[0]}


@app.get("/api/capas", tags=["mapa"])
def capas(conn=Depends(bd)):
    return filas(conn.execute("""SELECT c.*, COUNT(p.id) AS puntos FROM capas c
                                 LEFT JOIN puntos p ON p.capa_id = c.id AND p.publicado = 1
                                 GROUP BY c.id ORDER BY c.orden"""))


@app.get("/api/puntos", tags=["mapa"])
def puntos(capa: Optional[str] = None,
           hasta: Optional[int] = Query(None, description="solo hitos hasta este año (los puntos sin fecha se incluyen siempre)"),
           texto: Optional[str] = Query(None, min_length=2, max_length=60),
           conn=Depends(bd)):
    sql, args = CONSULTA_RESUMEN + " WHERE p.publicado = 1", []
    if capa:
        sql += " AND p.capa_id = ?"; args.append(capa)
    if hasta is not None:
        sql += " AND (p.anio IS NULL OR p.anio <= ?)"; args.append(hasta)
    if texto:
        sql += " AND (p.titulo LIKE ? OR p.descripcion LIKE ?)"; args += [f"%{texto}%"] * 2
    sql += " ORDER BY p.anio IS NULL, p.anio, p.titulo"
    return [resumen_punto(f) for f in conn.execute(sql, args).fetchall()]


@app.get("/api/puntos.geojson", tags=["mapa"], summary="Los puntos en GeoJSON (para QGIS u otros visores)")
def puntos_geojson(conn=Depends(bd)):
    return {"type": "FeatureCollection", "features": [
        {"type": "Feature", "id": f["id"],
         "geometry": {"type": "Point", "coordinates": [f["lon"], f["lat"]]},
         "properties": {k: f[k] for k in ("titulo", "capa_id", "anio", "fecha_texto", "color")}}
        for f in conn.execute(CONSULTA_RESUMEN + " WHERE p.publicado = 1").fetchall()]}


@app.get("/api/puntos/{pid}", tags=["mapa"])
def punto(pid: str, request: Request, conn=Depends(bd)):
    f = punto_o_404(conn, pid)
    capa = dict(conn.execute("SELECT id, nombre, color FROM capas WHERE id = ?", (f["capa_id"],)).fetchone())
    datos = resumen_punto(f) | {
        "descripcion": f["descripcion"],
        "fuente": f["fuente"],
        "capa": capa,
        "url": url_publica(request, f"/p/{pid}"),
        "recursos": filas(conn.execute("""SELECT id, tipo, titulo, url, autoria, licencia, texto_alt FROM recursos
                                          WHERE punto_id = ? ORDER BY orden, id""", (pid,))),
        "rutas": filas(conn.execute("""SELECT r.id, r.nombre, r.color, rp.orden FROM ruta_paradas rp
                                       JOIN rutas r ON r.id = rp.ruta_id WHERE rp.punto_id = ?""", (pid,))),
        "recuerdos": filas(conn.execute("""SELECT nombre, texto, date(creada) AS fecha FROM aportaciones
                                           WHERE punto_id = ? AND estado = 'aprobada' ORDER BY creada""", (pid,))),
    }
    return datos


@app.get("/api/cercanos", tags=["mapa"], summary="Puntos ordenados por distancia a una posición")
def cercanos(lat: float = Query(..., ge=-90, le=90), lon: float = Query(..., ge=-180, le=180),
             radio: int = Query(1500, ge=10, le=20000), conn=Depends(bd)):
    res = []
    for f in conn.execute(CONSULTA_RESUMEN + " WHERE p.publicado = 1").fetchall():
        d = distancia_m(lat, lon, f["lat"], f["lon"])
        if d <= radio:
            res.append(resumen_punto(f) | {"distancia_m": round(d), "minutos": minutos_a_pie(d)})
    return sorted(res, key=lambda x: x["distancia_m"])


def _ruta(conn, rid):
    r = conn.execute("SELECT * FROM rutas WHERE id = ?", (rid,)).fetchone()
    if r is None:
        raise HTTPException(404, f"No existe la ruta «{rid}»")
    paradas = filas(conn.execute("""SELECT p.id, p.titulo, p.titulo_corto, p.lat, p.lon, p.anio, p.fecha_texto, rp.orden
                                    FROM ruta_paradas rp JOIN puntos p ON p.id = rp.punto_id
                                    WHERE rp.ruta_id = ? AND p.publicado = 1 ORDER BY rp.orden""", (rid,)))
    total = 0
    for a, b in zip(paradas, paradas[1:]):
        b["tramo_m"] = round(distancia_m(a["lat"], a["lon"], b["lat"], b["lon"]))
        total += b["tramo_m"]
    return dict(r) | {"paradas": paradas, "distancia_m": total, "minutos": minutos_a_pie(total)}


@app.get("/api/rutas", tags=["rutas"])
def rutas(conn=Depends(bd)):
    res = []
    for r in conn.execute("SELECT id FROM rutas ORDER BY id").fetchall():
        ruta = _ruta(conn, r["id"])
        res.append({k: ruta[k] for k in ("id", "nombre", "descripcion", "color", "distancia_m", "minutos")} | {"paradas": len(ruta["paradas"])})
    return res


@app.get("/api/rutas/{rid}", tags=["rutas"])
def ruta(rid: str, conn=Depends(bd)):
    return _ruta(conn, rid)


@app.get("/api/puntos/{pid}/qr.png", tags=["mapa"], summary="Código QR que abre la ficha del punto",
         response_class=Response, responses={200: {"content": {"image/png": {}}}})
def qr(pid: str, request: Request, conn=Depends(bd)):
    punto_o_404(conn, pid)
    img = qrcode.make(url_publica(request, f"/p/{pid}"), box_size=10, border=2)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return Response(buf.getvalue(), media_type="image/png", headers={"Cache-Control": "public, max-age=86400"})


@app.get("/api/exportar/hitos.csv", tags=["integración"],
         summary="Hitos con fecha en el formato de «Ordena la historia» (Arcade, línea de SMR)")
def exportar_hitos(conn=Depends(bd)):
    salida = io.StringIO()
    w = csv.writer(salida)
    w.writerow(["id", "anio", "fecha_texto", "titulo", "descripcion", "foto", "foto_url"])
    for f in conn.execute(CONSULTA_RESUMEN + " WHERE p.publicado = 1 AND p.anio IS NOT NULL ORDER BY p.anio").fetchall():
        desc = f["descripcion"].split("\n\n")[0]
        if len(desc) > 240:
            desc = desc[:240].rsplit(" ", 1)[0] + "…"
        w.writerow([f["id"], f["anio"], f["fecha_texto"] or f["anio"], f["titulo_corto"] or f["titulo"], desc,
                    f"{f['id']}.jpg" if f["miniatura"] else "", f["miniatura"] or ""])
    return Response(salida.getvalue(), media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": 'attachment; filename="hitos.csv"'})


# --------------------------------------------------------------------------- aportaciones vecinales
class AportacionNueva(BaseModel):
    nombre: str = Field("", max_length=60, description="nombre o alias; puede quedar vacío")
    texto: str = Field(..., min_length=10, max_length=1000)
    consentimiento: bool = Field(..., description="acepta que se publique tras la revisión de la Mesa")
    web: str = Field("", description="campo trampa para robots: debe llegar vacío")


_envios = defaultdict(deque)


@app.post("/api/puntos/{pid}/aportaciones", tags=["aportaciones"], status_code=202,
          summary="Enviar un recuerdo o dato sobre un punto (queda pendiente de moderación)")
def aportar(pid: str, datos: AportacionNueva, request: Request, conn=Depends(bd)):
    punto_o_404(conn, pid)
    if not datos.consentimiento:
        raise HTTPException(422, "Hace falta aceptar que se publique tras la revisión")
    if datos.web:
        return {"estado": "pendiente"}                 # robot: se descarta sin decírselo
    ip = request.client.host if request.client else "?"
    ahora, cola = time.time(), _envios[ip]
    while cola and ahora - cola[0] > config.APORTACIONES_VENTANA_S:
        cola.popleft()
    if len(cola) >= config.APORTACIONES_MAX:
        raise HTTPException(429, "Demasiados envíos seguidos. Inténtalo más tarde.")
    cola.append(ahora)
    huella = hashlib.sha256(f"{config.SAL_IP}:{ip}".encode()).hexdigest()[:16]   # no se guarda la IP
    with conn:
        conn.execute("INSERT INTO aportaciones (punto_id, nombre, texto, huella_ip) VALUES (?, ?, ?, ?)",
                     (pid, datos.nombre.strip(), datos.texto.strip(), huella))
    return {"estado": "pendiente", "mensaje": "¡Gracias! La Mesa Comunitaria lo revisará antes de publicarlo."}


# --------------------------------------------------------------------------- API del panel editorial
class PuntoEdicion(BaseModel):
    titulo: Optional[str] = Field(None, min_length=3, max_length=200)
    titulo_corto: Optional[str] = Field(None, max_length=60)
    descripcion: Optional[str] = Field(None, max_length=5000)
    capa_id: Optional[str] = None
    lat: Optional[float] = Field(None, ge=40.30, le=40.40, description="dentro del entorno de Butarque")
    lon: Optional[float] = Field(None, ge=-3.72, le=-3.64)
    anio: Optional[int] = Field(None, ge=-1_000_000, le=2100)
    fecha_texto: Optional[str] = Field(None, max_length=40)
    nota_editorial: Optional[str] = Field(None, max_length=1000)
    publicado: Optional[bool] = None


class RecursoNuevo(BaseModel):
    tipo: Literal["imagen", "audio", "video", "enlace", "documento", "juego"]
    titulo: str = Field(..., min_length=2, max_length=120)
    url: str = Field(..., pattern=r"^(https?://|/media/)", max_length=500)
    autoria: str = Field(..., min_length=2, max_length=120)
    licencia: str = Field("Pendiente de confirmar", max_length=80)
    texto_alt: str = Field("", max_length=200)


class Importacion(BaseModel):
    kml_url: Optional[str] = Field(None, pattern=r"^https://")


@app.get("/api/admin/resumen", tags=["panel"], dependencies=[Depends(admin)])
def admin_resumen(conn=Depends(bd)):
    q = lambda sql: conn.execute(sql).fetchone()[0]
    ultima = conn.execute("SELECT fecha, origen FROM importaciones ORDER BY id DESC LIMIT 1").fetchone()
    return {"puntos": q("SELECT COUNT(*) FROM puntos"), "publicados": q("SELECT COUNT(*) FROM puntos WHERE publicado = 1"),
            "sin_fecha": q("SELECT COUNT(*) FROM puntos WHERE anio IS NULL"),
            "sin_descripcion": q("SELECT COUNT(*) FROM puntos WHERE descripcion = ''"),
            "fecha_por_revisar": q("SELECT COUNT(*) FROM puntos WHERE fecha_metodo = 'primer_anio'"),
            "editados": q("SELECT COUNT(*) FROM puntos WHERE editado_localmente = 1"),
            "fuera_del_kml": q("SELECT COUNT(*) FROM puntos WHERE origen = 'kml' AND en_kml = 0"),
            "recursos": q("SELECT COUNT(*) FROM recursos"),
            "aportaciones_pendientes": q("SELECT COUNT(*) FROM aportaciones WHERE estado = 'pendiente'"),
            "ultima_importacion": dict(ultima) if ultima else None}


@app.get("/api/admin/puntos", tags=["panel"], dependencies=[Depends(admin)])
def admin_puntos(conn=Depends(bd)):
    return filas(conn.execute("""SELECT p.id, p.titulo, p.titulo_corto, p.capa_id, c.color, p.anio, p.fecha_texto, p.fecha_metodo,
                                        p.publicado, p.editado_localmente, p.en_kml, p.origen, length(p.descripcion) AS largo,
                                        (SELECT COUNT(*) FROM recursos r WHERE r.punto_id = p.id) AS recursos,
                                        (SELECT COUNT(*) FROM aportaciones a WHERE a.punto_id = p.id AND a.estado = 'pendiente') AS pendientes
                                 FROM puntos p JOIN capas c ON c.id = p.capa_id
                                 ORDER BY c.orden, p.anio IS NULL, p.anio"""))


@app.get("/api/admin/puntos/{pid}", tags=["panel"], dependencies=[Depends(admin)])
def admin_punto(pid: str, conn=Depends(bd)):
    f = conn.execute("SELECT * FROM puntos WHERE id = ?", (pid,)).fetchone()
    if f is None:
        raise HTTPException(404, f"No existe el punto «{pid}»")
    return dict(f) | {"recursos": filas(conn.execute("SELECT * FROM recursos WHERE punto_id = ? ORDER BY orden, id", (pid,)))}


@app.put("/api/admin/puntos/{pid}", tags=["panel"], dependencies=[Depends(admin)])
def admin_editar(pid: str, cambios: PuntoEdicion, conn=Depends(bd)):
    actual = conn.execute("SELECT * FROM puntos WHERE id = ?", (pid,)).fetchone()
    if actual is None:
        raise HTTPException(404, f"No existe el punto «{pid}»")
    valores = cambios.model_dump(exclude_unset=True)
    if "capa_id" in valores and not conn.execute("SELECT 1 FROM capas WHERE id = ?", (valores["capa_id"],)).fetchone():
        raise HTTPException(422, f"No existe la capa «{valores['capa_id']}»")
    if not valores:
        return admin_punto(pid, conn)
    if "anio" in valores:
        valores["fecha_metodo"] = "editorial" if valores["anio"] is not None else None
    if any(k in valores and valores[k] != actual[k] for k in ("titulo", "descripcion", "lat", "lon", "capa_id")):
        valores["editado_localmente"] = 1              # la próxima importación del KML no lo pisará
    with conn:
        conn.execute(f"UPDATE puntos SET {', '.join(f'{k} = ?' for k in valores)}, actualizado = datetime('now') WHERE id = ?",
                     list(valores.values()) + [pid])
    return admin_punto(pid, conn)


@app.post("/api/admin/puntos/{pid}/recursos", tags=["panel"], dependencies=[Depends(admin)], status_code=201)
def admin_nuevo_recurso(pid: str, r: RecursoNuevo, conn=Depends(bd)):
    if not conn.execute("SELECT 1 FROM puntos WHERE id = ?", (pid,)).fetchone():
        raise HTTPException(404, f"No existe el punto «{pid}»")
    with conn:
        cur = conn.execute("""INSERT INTO recursos (punto_id, tipo, titulo, url, autoria, licencia, texto_alt, orden, origen)
                              VALUES (?, ?, ?, ?, ?, ?, ?, 50, 'propio')""",
                           (pid, r.tipo, r.titulo, r.url, r.autoria, r.licencia, r.texto_alt))
    return dict(conn.execute("SELECT * FROM recursos WHERE id = ?", (cur.lastrowid,)).fetchone())


@app.delete("/api/admin/recursos/{rid}", tags=["panel"], dependencies=[Depends(admin)], status_code=204)
def admin_borrar_recurso(rid: int, conn=Depends(bd)):
    r = conn.execute("SELECT origen FROM recursos WHERE id = ?", (rid,)).fetchone()
    if r is None:
        raise HTTPException(404, "No existe el recurso")
    if r["origen"] != "propio":
        raise HTTPException(409, f"Este recurso viene de {'My Maps' if r['origen'] == 'kml' else 'enriquecimiento.json'}: "
                                 "se cambia en su origen o volvería en la próxima importación")
    with conn:
        conn.execute("DELETE FROM recursos WHERE id = ?", (rid,))
    return Response(status_code=204)


@app.get("/api/admin/aportaciones", tags=["panel"], dependencies=[Depends(admin)])
def admin_aportaciones(estado: Literal["pendiente", "aprobada", "rechazada"] = "pendiente", conn=Depends(bd)):
    return filas(conn.execute("""SELECT a.id, a.punto_id, p.titulo AS punto, a.nombre, a.texto, a.estado, a.creada, a.revisada
                                 FROM aportaciones a JOIN puntos p ON p.id = a.punto_id
                                 WHERE a.estado = ? ORDER BY a.creada""", (estado,)))


@app.post("/api/admin/aportaciones/{aid}/{accion}", tags=["panel"], dependencies=[Depends(admin)])
def admin_moderar(aid: int, accion: Literal["aprobar", "rechazar"], conn=Depends(bd)):
    nuevo = {"aprobar": "aprobada", "rechazar": "rechazada"}[accion]
    with conn:
        cur = conn.execute("UPDATE aportaciones SET estado = ?, revisada = datetime('now') WHERE id = ?", (nuevo, aid))
    if cur.rowcount == 0:
        raise HTTPException(404, "No existe la aportación")
    return {"id": aid, "estado": nuevo}


@app.post("/api/admin/importar", tags=["panel"], dependencies=[Depends(admin)],
          summary="Volver a importar el mapa de My Maps (fichero configurado o URL)")
def admin_importar(datos: Importacion = Importacion(), conn=Depends(bd)):
    import urllib.request
    if datos.kml_url:
        try:
            with urllib.request.urlopen(datos.kml_url, timeout=30) as r:
                contenido, origen = r.read(), datos.kml_url
        except Exception as e:
            raise HTTPException(502, f"No se pudo descargar el KML: {e}")
    else:
        contenido, origen = config.KML.read_bytes(), str(config.KML)
    try:
        return importar(conn, contenido, cargar_enriquecimiento(), origen=origen)
    except Exception as e:
        raise HTTPException(422, f"El KML no se pudo importar: {e}")


@app.get("/api/admin/importaciones", tags=["panel"], dependencies=[Depends(admin)])
def admin_importaciones(conn=Depends(bd)):
    return filas(conn.execute("SELECT id, fecha, origen, informe FROM importaciones ORDER BY id DESC LIMIT 20"))


@app.get("/api/admin/comprobar", tags=["panel"], dependencies=[Depends(admin)], summary="Comprobar la clave del panel")
def admin_comprobar():
    return {"ok": True}


# --------------------------------------------------------------------------- clientes estáticos
config.MEDIA.mkdir(parents=True, exist_ok=True)
app.mount("/media", StaticFiles(directory=config.MEDIA), name="media")


@app.api_route("/p/{pid}", methods=["GET", "HEAD"], include_in_schema=False)
def enlace_directo(pid: str):
    """Los QR apuntan aquí: se sirve la app y ella abre la ficha del punto."""
    return FileResponse(config.CLIENTE / "index.html")


if config.ADMIN.exists():
    app.mount("/admin", StaticFiles(directory=config.ADMIN, html=True), name="admin")
if config.CLIENTE.exists():
    app.mount("/", StaticFiles(directory=config.CLIENTE, html=True), name="cliente")
else:
    @app.get("/", include_in_schema=False)
    def sin_cliente():
        return JSONResponse({"aviso": "No se encuentra la carpeta del cliente", "api": "/docs"})
