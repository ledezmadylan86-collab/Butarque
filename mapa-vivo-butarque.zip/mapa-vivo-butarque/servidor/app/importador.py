"""
Importa el mapa de My Maps (KML) a la base de datos del servidor de contenidos.

Se puede ejecutar tantas veces como se quiera: la primera vez crea los puntos y
las siguientes los actualiza. El informe que devuelve dice qué ha pasado con cada uno.

    python -m app.importador                         # KML de datos/mapa_butarque.kml
    python -m app.importador --kml-url "https://www.google.com/maps/d/kml?mid=...&forcekml=1"
    python -m app.importador --descargar-imagenes    # copia las fotos de My Maps a media/
    python -m app.importador --listar                # identificadores para enriquecimiento.json

Reglas de actualización (lo que el prototipo quiere validar):
  1. Un punto se reconoce por el título con que llegó del KML (kml_slug). Si en My Maps
     se le cambia el título, se reconoce por estar en el mismo sitio (menos de 25 m).
  2. Lo corregido en el panel editorial (editado_localmente) NO se pisa: si el KML trae
     otra cosa, se informa como conflicto.
  3. Un punto que desaparece del KML no se borra: se marca y se avisa.
  4. Las fotos de My Maps cambian de URL en cada exportación: se reconocen por su
     posición dentro del punto, para no duplicarlas.
"""

import argparse
import json
import sys
import urllib.request
from pathlib import Path

from . import config
from .db import conectar, crear_esquema
from .geo import distancia_m
from .kml import leer_kml, slug

DISTANCIA_RENOMBRADO_M = 25
CAMPOS_KML = ("titulo", "descripcion", "lat", "lon", "capa_id")


def _id_libre(conn, deseado):
    candidato, n = deseado, 2
    while conn.execute("SELECT 1 FROM puntos WHERE id = ?", (candidato,)).fetchone():
        candidato, n = f"{deseado}-{n}", n + 1
    return candidato


def _descargar(url, destino):
    destino.parent.mkdir(parents=True, exist_ok=True)
    peticion = urllib.request.Request(url, headers={"User-Agent": "mapa-vivo-butarque/1.0"})
    with urllib.request.urlopen(peticion, timeout=20) as r:
        destino.write_bytes(r.read())


def importar(conn, contenido_kml, enriquecimiento=None, origen="fichero", arcade_url=None,
             descargar_imagenes=False, media_dir=None):
    enriquecimiento = enriquecimiento or {}
    # Cada entrada se puede encontrar por el nombre con que llegó del KML (la clave) o por
    # el identificador estable ("id"). Lo segundo es lo que la salva de un cambio de título.
    enr_puntos = {}
    for clave, valor in enriquecimiento.get("puntos", {}).items():
        enr_puntos[clave] = valor
        if valor.get("id"):
            enr_puntos[valor["id"]] = valor
    arcade_url = (arcade_url or config.ARCADE_URL).rstrip("/")
    media_dir = Path(media_dir or config.MEDIA)
    datos = leer_kml(contenido_kml)
    fuente = f"«{datos['nombre']}» · Mesa Comunitaria de Butarque (Google My Maps)"

    informe = {"mapa": datos["nombre"], "nuevos": [], "actualizados": [], "renombrados": [],
               "sin_cambios": [], "conflictos": [], "desaparecidos": [], "imagenes": {"nuevas": 0, "url_cambiada": 0, "descargadas": 0, "errores": []},
               "avisos": []}

    with conn:                                         # todo o nada: si algo falla, no queda a medias
        # ---- capas
        enr_capas = enriquecimiento.get("capas", {})
        for c in datos["capas"]:
            conn.execute("""INSERT INTO capas (id, nombre, nombre_corto, color, orden) VALUES (?, ?, ?, ?, ?)
                            ON CONFLICT(id) DO UPDATE SET nombre = excluded.nombre, nombre_corto = excluded.nombre_corto,
                                                          color = excluded.color, orden = excluded.orden""",
                         (c["slug"], c["nombre"], enr_capas.get(c["slug"], {}).get("nombre_corto"), c["color"], c["orden"]))

        slugs_kml = {p["slug"] for p in datos["puntos"]}
        vistos = set()

        # ---- puntos
        for p in datos["puntos"]:
            capa_id = slug(p["capa"])
            existente = conn.execute("SELECT * FROM puntos WHERE kml_slug = ?", (p["slug"],)).fetchone()

            if existente is None:                      # ¿se le ha cambiado el título en My Maps?
                huerfanos = conn.execute("SELECT * FROM puntos WHERE origen = 'kml'").fetchall()
                for h in huerfanos:
                    if h["kml_slug"] not in slugs_kml and distancia_m(h["lat"], h["lon"], p["lat"], p["lon"]) <= DISTANCIA_RENOMBRADO_M:
                        existente = h
                        conn.execute("UPDATE puntos SET kml_slug = ? WHERE id = ?", (p["slug"], h["id"]))
                        informe["renombrados"].append({"id": h["id"], "antes": h["titulo"], "ahora": p["titulo"]})
                        break

            # datos editoriales: primero por el identificador estable, después por el nombre del KML
            enr = (enr_puntos.get(existente["id"]) if existente is not None else None) or enr_puntos.get(p["slug"], {})

            # fecha: la editorial manda sobre la deducida del texto
            if "anio" in enr:
                anio, metodo = enr["anio"], "editorial"
            else:
                anio, metodo = p["anio"], p["fecha_metodo"]
            fecha_texto = enr.get("fecha_texto", p["fecha_texto"])

            valores_kml = {"titulo": p["titulo"], "descripcion": p["descripcion"], "lat": p["lat"], "lon": p["lon"], "capa_id": capa_id}

            if existente is None:
                pid = _id_libre(conn, enr.get("id") or p["slug"])
                conn.execute("""INSERT INTO puntos (id, capa_id, titulo, titulo_corto, descripcion, lat, lon, anio, fecha_texto,
                                fecha_metodo, nota_editorial, fuente, origen, kml_slug)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'kml', ?)""",
                             (pid, capa_id, p["titulo"], enr.get("titulo_corto"), p["descripcion"], p["lat"], p["lon"],
                              anio, fecha_texto, metodo, enr.get("nota_editorial"), fuente, p["slug"]))
                informe["nuevos"].append(pid)
            else:
                pid = existente["id"]
                cambios = [c for c in CAMPOS_KML if existente[c] != valores_kml[c]]
                if cambios and existente["editado_localmente"]:
                    informe["conflictos"].append({"id": pid, "campos": cambios,
                                                  "detalle": "Editado en el panel: se conserva la versión local"})
                elif cambios:
                    conn.execute(f"UPDATE puntos SET {', '.join(f'{c} = ?' for c in cambios)}, actualizado = datetime('now') WHERE id = ?",
                                 [valores_kml[c] for c in cambios] + [pid])
                    informe["actualizados"].append({"id": pid, "campos": cambios})
                elif not any(r["id"] == pid for r in informe["renombrados"]):
                    informe["sin_cambios"].append(pid)
                if not existente["editado_localmente"]:
                    conn.execute("""UPDATE puntos SET titulo_corto = ?, anio = ?, fecha_texto = ?, fecha_metodo = ?,
                                    nota_editorial = ?, fuente = ? WHERE id = ?""",
                                 (enr.get("titulo_corto"), anio, fecha_texto, metodo, enr.get("nota_editorial"), fuente, pid))
                conn.execute("UPDATE puntos SET en_kml = 1 WHERE id = ?", (pid,))
            vistos.add(pid)

            # ---- fotos de My Maps: se reconocen por su posición, no por la URL
            actuales = conn.execute("SELECT * FROM recursos WHERE punto_id = ? AND origen = 'kml' ORDER BY orden", (pid,)).fetchall()
            for i, url in enumerate(p["imagenes"]):
                url_final = url
                if descargar_imagenes:
                    destino = media_dir / "kml" / f"{pid}-{i + 1}.jpg"
                    try:
                        _descargar(url, destino)
                        url_final = f"/media/kml/{destino.name}"
                        informe["imagenes"]["descargadas"] += 1
                    except Exception as e:             # sin red, enlace caducado...
                        informe["imagenes"]["errores"].append({"id": pid, "error": str(e)[:120]})
                texto_alt = f"Fotografía: {p['titulo']}"
                if i < len(actuales):
                    if actuales[i]["url"] != url_final:
                        conn.execute("UPDATE recursos SET url = ? WHERE id = ?", (url_final, actuales[i]["id"]))
                        informe["imagenes"]["url_cambiada"] += 1
                else:
                    conn.execute("""INSERT INTO recursos (punto_id, tipo, titulo, url, texto_alt, orden, origen)
                                    VALUES (?, 'imagen', ?, ?, ?, ?, 'kml')""", (pid, "Fotografía de la línea del tiempo", url_final, texto_alt, i))
                    informe["imagenes"]["nuevas"] += 1
            for sobrante in actuales[len(p["imagenes"]):]:
                conn.execute("DELETE FROM recursos WHERE id = ?", (sobrante["id"],))

            # ---- recursos del fichero editorial: se regeneran en cada importación
            conn.execute("DELETE FROM recursos WHERE punto_id = ? AND origen = 'enriquecimiento'", (pid,))
            for j, r in enumerate(enr.get("recursos", [])):
                conn.execute("""INSERT INTO recursos (punto_id, tipo, titulo, url, autoria, licencia, texto_alt, orden, origen)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'enriquecimiento')""",
                             (pid, r["tipo"], r.get("titulo", ""), r["url"].replace("{ARCADE}", arcade_url),
                              r.get("autoria", "Pendiente de confirmar"), r.get("licencia", "Pendiente de confirmar"),
                              r.get("texto_alt", ""), 100 + j))

        # ---- puntos que estaban y ya no vienen en el KML: no se borran
        for fila in conn.execute("SELECT id, titulo FROM puntos WHERE origen = 'kml'").fetchall():
            if fila["id"] not in vistos:
                conn.execute("UPDATE puntos SET en_kml = 0 WHERE id = ?", (fila["id"],))
                informe["desaparecidos"].append(fila["id"])

        # ---- rutas
        for ruta in enriquecimiento.get("rutas", []):
            conn.execute("""INSERT INTO rutas (id, nombre, descripcion, color) VALUES (?, ?, ?, ?)
                            ON CONFLICT(id) DO UPDATE SET nombre = excluded.nombre, descripcion = excluded.descripcion, color = excluded.color""",
                         (ruta["id"], ruta["nombre"], ruta.get("descripcion", ""), ruta.get("color", "#333333")))
            conn.execute("DELETE FROM ruta_paradas WHERE ruta_id = ?", (ruta["id"],))
            orden = 0
            for pid in ruta["paradas"]:
                if conn.execute("SELECT 1 FROM puntos WHERE id = ?", (pid,)).fetchone():
                    conn.execute("INSERT INTO ruta_paradas (ruta_id, punto_id, orden) VALUES (?, ?, ?)", (ruta["id"], pid, orden))
                    orden += 1
                else:
                    informe["avisos"].append(f"La ruta «{ruta['nombre']}» nombra un punto que no existe: {pid}")

        # ---- avisos de calidad del contenido
        for f in conn.execute("SELECT id, titulo, descripcion, anio, fecha_metodo FROM puntos WHERE publicado = 1").fetchall():
            if f["anio"] is None:
                informe["avisos"].append(f"Sin fecha: {f['id']} (se muestra siempre, fuera de la línea del tiempo)")
            elif f["fecha_metodo"] == "primer_anio":
                informe["avisos"].append(f"Fecha deducida del primer año del texto ({f['anio']}), conviene revisarla: {f['id']}")
            if not f["descripcion"]:
                informe["avisos"].append(f"Sin descripción: {f['id']}")
        sin_autoria = conn.execute("SELECT COUNT(*) FROM recursos WHERE tipo = 'imagen' AND autoria LIKE 'Pendiente%'").fetchone()[0]
        if sin_autoria:
            informe["avisos"].append(f"{sin_autoria} imágenes sin autoría ni licencia confirmadas")

        conn.execute("INSERT INTO importaciones (origen, informe) VALUES (?, ?)", (origen, json.dumps(informe, ensure_ascii=False)))
    return informe


def resumen(informe):
    lineas = [f"Mapa: {informe['mapa']}"]
    for clave in ("nuevos", "actualizados", "renombrados", "sin_cambios", "conflictos", "desaparecidos"):
        lineas.append(f"  {clave:13} {len(informe[clave])}")
    im = informe["imagenes"]
    lineas.append(f"  imágenes      {im['nuevas']} nuevas, {im['url_cambiada']} con URL cambiada, {im['descargadas']} descargadas, {len(im['errores'])} errores")
    if informe["avisos"]:
        lineas.append(f"Avisos ({len(informe['avisos'])}):")
        lineas += [f"  - {a}" for a in informe["avisos"]]
    return "\n".join(lineas)


def cargar_enriquecimiento(ruta=None):
    ruta = Path(ruta or config.ENRIQUECIMIENTO)
    return json.loads(ruta.read_text(encoding="utf-8")) if ruta.exists() else {}


def main(argv=None):
    ap = argparse.ArgumentParser(description="Importa el mapa de My Maps al servidor de contenidos")
    ap.add_argument("--kml", default=str(config.KML), help="fichero KML")
    ap.add_argument("--kml-url", help="descargar el KML de esta dirección")
    ap.add_argument("--enriquecimiento", default=str(config.ENRIQUECIMIENTO))
    ap.add_argument("--db", default=str(config.DB))
    ap.add_argument("--descargar-imagenes", action="store_true", help="copiar las fotos de My Maps a media/kml/")
    ap.add_argument("--listar", action="store_true", help="solo listar los identificadores que genera el KML")
    a = ap.parse_args(argv)

    if a.kml_url:
        with urllib.request.urlopen(a.kml_url, timeout=30) as r:
            contenido, origen = r.read(), a.kml_url
    else:
        contenido, origen = Path(a.kml).read_bytes(), a.kml

    if a.listar:
        for p in leer_kml(contenido)["puntos"]:
            print(f"{p['slug']:52} {p['titulo']}")
        return 0

    conn = conectar(a.db)
    crear_esquema(conn)
    informe = importar(conn, contenido, cargar_enriquecimiento(a.enriquecimiento), origen=origen,
                       descargar_imagenes=a.descargar_imagenes)
    print(resumen(informe))
    return 0


if __name__ == "__main__":
    sys.exit(main())
