"""
Base de datos SQLite del servidor de contenidos.

Modelo (una tabla por concepto del dominio):

  capas ──< puntos ──< recursos           un punto tiene fotos, audios, juegos, enlaces...
                 │  └─< aportaciones      recuerdos enviados por el vecindario (moderados)
                 └──< ruta_paradas >── rutas
  importaciones                           registro de cada importación del KML

Decisiones que el prototipo quiere validar:
  - puntos.id es un identificador PROPIO y estable (sale en las URL y en los QR).
    El título de My Maps puede cambiar sin romper nada: kml_slug guarda con qué
    nombre llegó del KML para reconocerlo en la siguiente importación.
  - fecha_metodo dice de dónde salió el año: del texto (heurística) o de la edición.
  - editado_localmente protege lo que se ha corregido en el panel frente a una
    reimportación del KML.
"""

import sqlite3
from pathlib import Path

ESQUEMA = """
CREATE TABLE IF NOT EXISTS capas (
    id        TEXT PRIMARY KEY,
    nombre    TEXT NOT NULL,
    nombre_corto TEXT,
    color     TEXT NOT NULL DEFAULT '#7F7F7F',
    orden     INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS puntos (
    id                  TEXT PRIMARY KEY,
    capa_id             TEXT NOT NULL REFERENCES capas(id),
    titulo              TEXT NOT NULL,
    titulo_corto        TEXT,
    descripcion         TEXT NOT NULL DEFAULT '',
    lat                 REAL NOT NULL CHECK (lat BETWEEN -90 AND 90),
    lon                 REAL NOT NULL CHECK (lon BETWEEN -180 AND 180),
    anio                INTEGER,
    fecha_texto         TEXT,
    fecha_metodo        TEXT,             -- hace_n_anios | antes_de_cristo | parentesis | final_del_texto | primer_anio | editorial
    nota_editorial      TEXT,
    fuente              TEXT,
    origen              TEXT NOT NULL DEFAULT 'kml' CHECK (origen IN ('kml', 'propio')),
    kml_slug            TEXT UNIQUE,
    editado_localmente  INTEGER NOT NULL DEFAULT 0,
    publicado           INTEGER NOT NULL DEFAULT 1,
    en_kml              INTEGER NOT NULL DEFAULT 1,   -- 0 si desapareció del mapa en la última importación
    actualizado         TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS recursos (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    punto_id  TEXT NOT NULL REFERENCES puntos(id) ON DELETE CASCADE,
    tipo      TEXT NOT NULL CHECK (tipo IN ('imagen', 'audio', 'video', 'enlace', 'documento', 'juego')),
    titulo    TEXT NOT NULL DEFAULT '',
    url       TEXT NOT NULL,
    autoria   TEXT NOT NULL DEFAULT 'Pendiente de confirmar',
    licencia  TEXT NOT NULL DEFAULT 'Pendiente de confirmar',
    texto_alt TEXT NOT NULL DEFAULT '',
    orden     INTEGER NOT NULL DEFAULT 0,
    origen    TEXT NOT NULL DEFAULT 'propio' CHECK (origen IN ('kml', 'enriquecimiento', 'propio'))
);

CREATE TABLE IF NOT EXISTS rutas (
    id          TEXT PRIMARY KEY,
    nombre      TEXT NOT NULL,
    descripcion TEXT NOT NULL DEFAULT '',
    color       TEXT NOT NULL DEFAULT '#333333'
);

CREATE TABLE IF NOT EXISTS ruta_paradas (
    ruta_id   TEXT NOT NULL REFERENCES rutas(id) ON DELETE CASCADE,
    punto_id  TEXT NOT NULL REFERENCES puntos(id) ON DELETE CASCADE,
    orden     INTEGER NOT NULL,
    PRIMARY KEY (ruta_id, orden)
);

CREATE TABLE IF NOT EXISTS aportaciones (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    punto_id  TEXT NOT NULL REFERENCES puntos(id) ON DELETE CASCADE,
    nombre    TEXT NOT NULL DEFAULT '',
    texto     TEXT NOT NULL,
    estado    TEXT NOT NULL DEFAULT 'pendiente' CHECK (estado IN ('pendiente', 'aprobada', 'rechazada')),
    huella_ip TEXT NOT NULL DEFAULT '',
    creada    TEXT NOT NULL DEFAULT (datetime('now')),
    revisada  TEXT
);

CREATE TABLE IF NOT EXISTS importaciones (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    fecha    TEXT NOT NULL DEFAULT (datetime('now')),
    origen   TEXT NOT NULL,
    informe  TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_puntos_capa ON puntos(capa_id);
CREATE INDEX IF NOT EXISTS idx_recursos_punto ON recursos(punto_id);
CREATE INDEX IF NOT EXISTS idx_aportaciones_estado ON aportaciones(estado);
"""


def conectar(ruta):
    ruta = Path(ruta)
    ruta.parent.mkdir(parents=True, exist_ok=True)
    # FastAPI puede abrir la conexión en un hilo y usarla en otro dentro de la MISMA petición.
    # Es seguro porque cada petición tiene su propia conexión (ver bd() en main.py).
    conn = sqlite3.connect(ruta, check_same_thread=False, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")        # lecturas y escrituras a la vez sin bloquearse
    return conn


MIGRACIONES = [
    "ALTER TABLE capas ADD COLUMN nombre_corto TEXT",          # v0.2
]


def crear_esquema(conn):
    conn.executescript(ESQUEMA)
    for sql in MIGRACIONES:                                    # bases creadas con versiones anteriores
        try:
            conn.execute(sql)
        except sqlite3.OperationalError:                       # la columna ya existe
            pass
    conn.commit()


def filas(cursor):
    return [dict(f) for f in cursor.fetchall()]
