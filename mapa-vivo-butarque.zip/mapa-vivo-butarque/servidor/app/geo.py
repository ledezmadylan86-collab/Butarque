"""Cálculos geográficos sencillos (suficientes a escala de barrio)."""

import math

RADIO_TIERRA_M = 6_371_000
VELOCIDAD_A_PIE_KMH = 4.5


def distancia_m(lat1, lon1, lat2, lon2):
    """Distancia en metros entre dos puntos (fórmula del semiverseno)."""
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * RADIO_TIERRA_M * math.asin(math.sqrt(a))


def minutos_a_pie(metros):
    return round(metros / 1000 / VELOCIDAD_A_PIE_KMH * 60)
