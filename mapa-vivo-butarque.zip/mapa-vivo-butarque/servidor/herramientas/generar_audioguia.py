"""
Genera una audioguía de PRUEBA con voz sintética a partir de la descripción de un punto.

Sirve para validar el reproductor de la app sin tener aún grabaciones reales.
Las audioguías definitivas serán grabaciones del vecindario (con su consentimiento).

    python herramientas/generar_audioguia.py la-copa-de-villaverde

Necesita espeak-ng y ffmpeg:  sudo apt install espeak-ng ffmpeg
"""

import subprocess
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app import config                      # noqa: E402
from app.db import conectar                 # noqa: E402


def main(punto_id):
    conn = conectar(config.DB)
    p = conn.execute("SELECT titulo, descripcion, fecha_texto FROM puntos WHERE id = ?", (punto_id,)).fetchone()
    if p is None:
        sys.exit(f"No existe el punto {punto_id}. Ejecuta antes: python -m app.importador")
    texto = f"{p['titulo']}. {p['fecha_texto'] or ''}. {p['descripcion']}"
    destino = config.MEDIA / "audio" / f"{punto_id}.mp3"
    destino.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        wav = Path(tmp) / "voz.wav"
        subprocess.run(["espeak-ng", "-v", "es", "-s", "150", "-w", str(wav), texto], check=True)
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(wav), "-ac", "1", "-b:a", "48k", str(destino)], check=True)
    print(f"Audioguía de prueba: {destino} ({destino.stat().st_size // 1024} KB)")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "la-copa-de-villaverde")
